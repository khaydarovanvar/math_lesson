/* Site language: English / O'zbekcha / Русский.
   Two separate things live here:

   1. UI  — the site's own chrome (buttons, headings, labels). Every page
      reads these through t(key), so switching language relabels the whole
      interface immediately, everywhere, with no network request.

   2. Lesson CONTENT — a topic's explanation, examples, quiz, practice and
      homework. Most topics are English-only prose today; a topic that has
      been fully translated carries a `T.i18n = { uz: {...}, ru: {...} }`
      object alongside its English fields. `pick(T, lang, field)` reads the
      translated field when the topic has one, and silently falls back to
      the English field when it does not — so switching language never
      breaks a page, it just leaves the not-yet-translated lessons in
      English until they are written. */
(function (w) {
  'use strict';

  var KEY = 'akm-lang';
  var SUPPORTED = ['en', 'uz', 'ru'];

  function lang() {
    var v = null;
    try { v = localStorage.getItem(KEY); } catch (e) { /* private mode */ }
    return SUPPORTED.indexOf(v) > -1 ? v : 'en';
  }

  function setLang(l) {
    if (SUPPORTED.indexOf(l) < 0) return;
    try { localStorage.setItem(KEY, l); } catch (e) { /* ignore */ }
    document.documentElement.setAttribute('lang', l === 'en' ? 'en' : l);
    var ev;
    try { ev = new CustomEvent('akm:langchange', { detail: { lang: l } }); }
    catch (e) { ev = document.createEvent('Event'); ev.initEvent('akm:langchange', true, true); ev.detail = { lang: l }; }
    w.dispatchEvent(ev);
  }

  /* ---------------- UI chrome dictionary ---------------- */
  var UI = {
    en: {
      navHome: 'Home', navGrades: 'Grades 5–11', navPlans: 'Annual plans',
      navTerms: 'Terminology', navAbout: 'About the course',
      menuComing: 'coming', menuAllLessons: 'all {n} lessons',
      searchTitle: 'Search the topics', searchPlaceholder: 'Search {n} topics — try “chord”, “vatar”, “хорда”',
      searchNone: 'Nothing matched. Try a shorter word.',
      themeTitle: 'Switch colour theme', menuTitle: 'Menu',
      footNote: 'Lesson resources for the Uzbekistan national programme and Cambridge Lower ' +
        'Secondary Mathematics. Built around 40-minute lessons: explanation, guided practice, ' +
        '21 graded problems and short homework.',
      langLabel: 'Language',

      back: 'Back to Grade {g}', home: 'Home', grade: 'Grade',
      algebra: 'Algebra', geometry: 'Geometry', mathematics: 'Mathematics', quarter: 'Quarter',
      lesson: 'Lesson {r}', perHour: '× 40 min',
      clock: 'Lesson clock', objectives: 'Learning objectives', textbook: 'Textbook',
      national: 'National', cambridge: 'Cambridge', workbook: 'Workbook',
      onThisPage: 'On this page', print: 'Print this lesson',
      secExplain: 'Explanation', secExamples: 'Worked examples', secModel: 'Interactive model',
      secTerms: 'Terminology', secCheck: 'Quick check', secPractice: 'Practice · 21',
      secHomework: 'Homework', secPracticeHead: 'Practice · 21 problems',
      termsNote: 'Write these on the board at the start. Learners meet the national programme ' +
        'in Uzbek or Russian and the Cambridge papers in English — the three columns are the same idea.',
      termsNote2: 'Stress the words in bold in the explanation above; ask for the ' +
        'Uzbek and Russian back before moving on.',
      practiceNote: 'Seven at each level. Set the easy row for everyone, the medium row for the ' +
        'main body of the class, and the hard row for those who finish early.',
      easy: 'Easy · warm the idea up', medium: 'Medium · the standard question', hard: 'Hard · stretch and reason',
      problems: 'problems', showAnswers: 'Show answers', hideAnswers: 'Hide answers',
      example: 'Example {n}', answer: 'Answer',
      homeworkDefault: 'Set for the next lesson',
      prev: '← Previous', next: 'Next →', allTopics: 'All topics',
      modelDefault: 'Show this on the board and let a learner drive it.',

      chooseQuarter: 'Choose a quarter', teachingYear: 'The teaching year', live: 'live', soon: 'soon',
      hours: 'hours', beingWritten: 'Being written — the annual plan for this quarter is already published.',
      topicsWrittenSoFar: '{n} topic pages written so far, each with an explanation, figures, an ' +
        'interactive model, three-language terminology, 21 graded problems and homework.'
    },
    uz: {
      navHome: 'Bosh sahifa', navGrades: '5–11-sinflar', navPlans: 'Yillik rejalar',
      navTerms: 'Atamalar', navAbout: 'Kurs haqida',
      menuComing: 'tayyorlanmoqda', menuAllLessons: 'barcha {n} dars',
      searchTitle: 'Mavzularni qidirish', searchPlaceholder: '{n} ta mavzuni qidiring — masalan, “chord”, “vatar”, “хорда”',
      searchNone: 'Hech narsa topilmadi. Qisqaroq so‘z kiriting.',
      themeTitle: 'Rang mavzusini almashtirish', menuTitle: 'Menyu',
      footNote: 'O‘zbekiston milliy dasturi va Cambridge Lower Secondary Mathematics bo‘yicha dars ' +
        'materiallari. Har bir dars 40 daqiqalik: tushuntirish, boshqariladigan mashq, ' +
        '21 ta darajali masala va qisqa uy vazifasi.',
      langLabel: 'Til',

      back: '{g}-sinfga qaytish', home: 'Bosh sahifa', grade: 'Sinf',
      algebra: 'Algebra', geometry: 'Geometriya', mathematics: 'Matematika', quarter: 'Chorak',
      lesson: '{r}-dars', perHour: '× 40 daq',
      clock: 'Dars soati', objectives: 'O‘quv maqsadlari', textbook: 'Darslik',
      national: 'Milliy', cambridge: 'Cambridge', workbook: 'Ish daftari',
      onThisPage: 'Shu sahifada', print: 'Darsni chop etish',
      secExplain: 'Tushuntirish', secExamples: 'Yechilgan misollar', secModel: 'Interaktiv model',
      secTerms: 'Atamalar', secCheck: 'Tezkor tekshiruv', secPractice: 'Mashq · 21',
      secHomework: 'Uy vazifasi', secPracticeHead: 'Mashq · 21 ta masala',
      termsNote: 'Darsning boshida bularni doskaga yozing. O‘quvchilar milliy dasturni o‘zbek yoki rus ' +
        'tilida, Cambridge ishlarini esa ingliz tilida uchratadi — uch ustun bir xil g‘oyani ifodalaydi.',
      termsNote2: 'Yuqoridagi tushuntirishda qalin harflar bilan berilgan so‘zlarga urg‘u bering; ' +
        'davom etishdan oldin ularning o‘zbekcha va ruscha shaklini so‘rang.',
      practiceNote: 'Har darajada yettitadan. Oson qatorni hammaga, o‘rtacha qatorni sinfning asosiy ' +
        'qismiga, qiyin qatorni esa erta tugatganlarga bering.',
      easy: 'Oson · g‘oyani isitish', medium: 'O‘rtacha · andoza masala', hard: 'Qiyin · cho‘zish va fikrlash',
      problems: 'ta masala', showAnswers: 'Javoblarni ko‘rsatish', hideAnswers: 'Javoblarni yashirish',
      example: '{n}-misol', answer: 'Javob',
      homeworkDefault: 'Keyingi darsga tayyorlang',
      prev: '← Oldingi', next: 'Keyingi →', allTopics: 'Barcha mavzular',
      modelDefault: 'Buni doskada ko‘rsating va o‘quvchiga o‘zi boshqarishga ruxsat bering.',

      chooseQuarter: 'Chorakni tanlang', teachingYear: 'O‘quv yili', live: 'tayyor', soon: 'tayyorlanmoqda',
      hours: 'soat', beingWritten: 'Hozircha yozilmoqda — bu chorak uchun yillik reja allaqachon e’lon qilingan.',
      topicsWrittenSoFar: 'Hozirgacha {n} ta mavzu sahifasi yozilgan, har biri tushuntirish, chizmalar, ' +
        'interaktiv model, uch tilli atamalar, 21 ta darajali masala va uy vazifasidan iborat.'
    },
    ru: {
      navHome: 'Главная', navGrades: '5–11 классы', navPlans: 'Годовые планы',
      navTerms: 'Терминология', navAbout: 'О курсе',
      menuComing: 'готовится', menuAllLessons: 'все {n} уроков',
      searchTitle: 'Поиск по темам', searchPlaceholder: 'Поиск среди {n} тем — например, «chord», «vatar», «хорда»',
      searchNone: 'Ничего не найдено. Попробуйте короче.',
      themeTitle: 'Переключить цветовую тему', menuTitle: 'Меню',
      footNote: 'Материалы уроков по национальной программе Узбекистана и Cambridge Lower Secondary ' +
        'Mathematics. Каждый урок рассчитан на 40 минут: объяснение, практика под руководством, ' +
        '21 разноуровневая задача и короткое домашнее задание.',
      langLabel: 'Язык',

      back: 'Назад, в {g} класс', home: 'Главная', grade: 'Класс',
      algebra: 'Алгебра', geometry: 'Геометрия', mathematics: 'Математика', quarter: 'Четверть',
      lesson: 'Урок {r}', perHour: '× 40 мин',
      clock: 'Хронометраж урока', objectives: 'Цели урока', textbook: 'Учебник',
      national: 'Национальный', cambridge: 'Cambridge', workbook: 'Рабочая тетрадь',
      onThisPage: 'На этой странице', print: 'Распечатать урок',
      secExplain: 'Объяснение', secExamples: 'Разобранные примеры', secModel: 'Интерактивная модель',
      secTerms: 'Терминология', secCheck: 'Быстрая проверка', secPractice: 'Практика · 21',
      secHomework: 'Домашнее задание', secPracticeHead: 'Практика · 21 задача',
      termsNote: 'Запишите это на доске в начале урока. Ученики встречают национальную программу на ' +
        'узбекском или русском, а задания Cambridge — на английском; три столбца — об одном и том же.',
      termsNote2: 'Выделите голосом слова, набранные жирным шрифтом в объяснении выше; прежде чем ' +
        'двигаться дальше, спросите их узбекский и русский варианты.',
      practiceNote: 'По семь задач на каждый уровень. Лёгкий ряд — для всех, средний — для основной ' +
        'части класса, сложный — для тех, кто закончил раньше.',
      easy: 'Лёгкий · разогрев', medium: 'Средний · стандартная задача', hard: 'Сложный · на рассуждение',
      problems: 'задач', showAnswers: 'Показать ответы', hideAnswers: 'Скрыть ответы',
      example: 'Пример {n}', answer: 'Ответ',
      homeworkDefault: 'Задание к следующему уроку',
      prev: '← Назад', next: 'Далее →', allTopics: 'Все темы',
      modelDefault: 'Покажите это на доске и дайте ученику самому управлять моделью.',

      chooseQuarter: 'Выберите четверть', teachingYear: 'Учебный год', live: 'готово', soon: 'скоро',
      hours: 'часов', beingWritten: 'Пока пишется — годовой план на эту четверть уже опубликован.',
      topicsWrittenSoFar: 'Уже написано {n} страниц тем, в каждой — объяснение, рисунки, интерактивная ' +
        'модель, трёхъязычная терминология, 21 разноуровневая задача и домашнее задание.'
    }
  };

  function t(key, vars) {
    var l = lang();
    var s = (UI[l] && UI[l][key] != null) ? UI[l][key] : (UI.en[key] != null ? UI.en[key] : key);
    if (vars) {
      for (var k in vars) if (Object.prototype.hasOwnProperty.call(vars, k)) {
        s = s.replace('{' + k + '}', vars[k]);
      }
    }
    return s;
  }

  /* Lesson content: field-by-field fallback to English. `field` may be a
     dotted path is not needed here — every translatable field sits at the
     top level of T.i18n[lang]. */
  function pick(T, field) {
    var l = lang();
    if (l !== 'en' && T && T.i18n && T.i18n[l] && T.i18n[l][field] !== undefined) {
      return T.i18n[l][field];
    }
    return T ? T[field] : undefined;
  }

  /* True once a topic has a full translation for the given (or current)
     language — used to show a small "not yet translated" note instead of
     silently mixing languages without saying so. */
  function hasTranslation(T, l) {
    l = l || lang();
    return !!(T && T.i18n && T.i18n[l]);
  }

  w.AKM_I18N = {
    SUPPORTED: SUPPORTED, lang: lang, setLang: setLang, t: t, pick: pick, hasTranslation: hasTranslation
  };
})(window);

/* Interactive lesson models. INT.mount(container, spec) — no dependencies. */
(function (w, d) {
  'use strict';

  /* ---------- small helpers ---------- */
  function el(tag, attrs, kids) {
    var n = d.createElementNS(tag === 'svg' || SVGT[tag] ? 'http://www.w3.org/2000/svg' : 'http://www.w3.org/1999/xhtml', tag);
    for (var k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    (kids || []).forEach(function (c) { n.appendChild(typeof c === 'string' ? d.createTextNode(c) : c); });
    return n;
  }
  var SVGT = { circle: 1, line: 1, path: 1, polygon: 1, polyline: 1, text: 1, g: 1, rect: 1, tspan: 1 };
  function S(tag, attrs, text) {
    var n = d.createElementNS('http://www.w3.org/2000/svg', tag);
    for (var k in attrs) if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    if (text != null) n.textContent = text;
    return n;
  }
  function r1(v) { return Math.round(v * 10) / 10; }
  function r2(v) { return Math.round(v * 100) / 100; }
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
  function angleDeg(v, p, q) {
    var a = Math.atan2(p[1] - v[1], p[0] - v[0]), b = Math.atan2(q[1] - v[1], q[0] - v[0]);
    var t = Math.abs(a - b) * 180 / Math.PI; return t > 180 ? 360 - t : t;
  }
  function mid(a, b) { return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; }

  /* frame: header + body, returns {body, read} */
  function frame(host, title, hint) {
    host.innerHTML = '';
    host.className = 'ilab';
    var h = el('div', { 'class': 'ih' });
    h.innerHTML = '<span class="it">' + title + '</span><span class="ihint">' + (hint || '') + '</span>';
    var b = el('div', { 'class': 'ib' });
    host.appendChild(h); host.appendChild(b);
    return b;
  }
  function readoutBar(body, items) {
    var bar = el('div', { 'class': 'readout' });
    var map = {};
    items.forEach(function (t) {
      var n = el('div', { 'class': 'rd' });
      n.innerHTML = t + ' <b data-k="' + t + '">–</b>';
      map[t] = n.querySelector('b');
      bar.appendChild(n);
    });
    body.appendChild(bar);
    return map;
  }
  function slider(body, label, min, max, val, step, onChange) {
    var c = el('div', { 'class': 'ctrl' });
    var id = 'sl' + Math.random().toString(36).slice(2, 8);
    c.innerHTML = '<label for="' + id + '">' + label + '</label>' +
      '<input id="' + id + '" type="range" min="' + min + '" max="' + max + '" step="' + step +
      '" value="' + val + '"><output>' + val + '</output>';
    var inp = c.querySelector('input'), out = c.querySelector('output');
    inp.addEventListener('input', function () { out.textContent = inp.value; onChange(parseFloat(inp.value)); });
    body.appendChild(c);
    return { input: inp, output: out, set: function (v) { inp.value = v; out.textContent = v; } };
  }
  function ctrlRow(body) { var r = el('div', { 'class': 'ctrls' }); body.appendChild(r); return r; }
  function stage(body, vb, wpx) {
    var st = el('div', { 'class': 'stage' });
    var svg = S('svg', { viewBox: vb, width: wpx || 460, xmlns: 'http://www.w3.org/2000/svg' });
    svg.style.maxWidth = '100%'; svg.style.height = 'auto';
    st.appendChild(svg); body.appendChild(st);
    return svg;
  }
  /* make circles draggable inside an svg; cb(id,x,y) */
  function draggable(svg, handles, cb) {
    var active = null;
    function pt(evt) {
      var m = svg.getScreenCTM();
      var p = svg.createSVGPoint(); p.x = evt.clientX; p.y = evt.clientY;
      var q = p.matrixTransform(m.inverse());
      return [q.x, q.y];
    }
    handles.forEach(function (h) {
      h.node.classList.add('handle');
      h.node.setAttribute('tabindex', '0');
      h.node.addEventListener('pointerdown', function (e) {
        active = h; h.node.setPointerCapture(e.pointerId); e.preventDefault();
      });
      h.node.addEventListener('keydown', function (e) {
        var s = e.shiftKey ? 10 : 3, dx = 0, dy = 0;
        if (e.key === 'ArrowLeft') dx = -s; else if (e.key === 'ArrowRight') dx = s;
        else if (e.key === 'ArrowUp') dy = -s; else if (e.key === 'ArrowDown') dy = s; else return;
        e.preventDefault();
        cb(h.id, h.get()[0] + dx, h.get()[1] + dy);
      });
    });
    svg.addEventListener('pointermove', function (e) {
      if (!active) return;
      var p = pt(e); cb(active.id, p[0], p[1]);
    });
    svg.addEventListener('pointerup', function () { active = null; });
    svg.addEventListener('pointercancel', function () { active = null; });
  }
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }

  var INT = {};

  /* ============ 1. interior / exterior angles of a polygon ============ */
  INT.polygonAngles = function (host, opt) {
    var body = frame(host, 'Angle sum of a polygon',
      'Move the slider — the polygon splits into triangles from one vertex.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 340 260', 420);
    var read = readoutBar(body, ['sides n', 'triangles', 'interior sum', 'each angle', 'exterior sum']);
    var n = 6;
    function draw() {
      svg.innerHTML = '';
      var cx = 170, cy = 128, R = 100, pts = [], i;
      for (i = 0; i < n; i++) {
        var a = -Math.PI / 2 + i * 2 * Math.PI / n;
        pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
      }
      svg.appendChild(S('polygon', {
        points: pts.map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2, 'stroke-linejoin': 'round'
      }));
      for (i = 2; i < n - 1; i++) {
        svg.appendChild(S('line', {
          x1: r1(pts[0][0]), y1: r1(pts[0][1]), x2: r1(pts[i][0]), y2: r1(pts[i][1]),
          stroke: 'var(--faint)', 'stroke-width': 1.4, 'stroke-dasharray': '5 4'
        }));
      }
      for (i = 1; i < n - 1; i++) {
        var c = [(pts[0][0] + pts[i][0] + pts[i + 1][0]) / 3, (pts[0][1] + pts[i][1] + pts[i + 1][1]) / 3];
        var t = S('text', {
          x: r1(c[0]), y: r1(c[1]), 'text-anchor': 'middle', 'dominant-baseline': 'middle',
          'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--brass)'
        }, String(i));
        svg.appendChild(t);
      }
      pts.forEach(function (p) {
        svg.appendChild(S('circle', { cx: r1(p[0]), cy: r1(p[1]), r: 3.4, fill: 'currentColor' }));
      });
      svg.appendChild(S('text', {
        x: 170, y: 248, 'text-anchor': 'middle', 'font-family': 'Spectral, Georgia, serif',
        'font-size': 14, fill: 'var(--brand)'
      }, '180° × (' + n + ' − 2) = ' + (180 * (n - 2)) + '°'));
      read['sides n'].textContent = n;
      read['triangles'].textContent = n - 2;
      read['interior sum'].textContent = 180 * (n - 2) + '°';
      read['each angle'].textContent = r1(180 * (n - 2) / n) + '°';
      read['exterior sum'].textContent = '360°';
    }
    slider(row, 'number of sides n', 3, 12, 6, 1, function (v) { n = v; draw(); });
    draw();
  };

  /* ============ 2. quadrilateral explorer (drag the vertices) ============ */
  INT.quadExplorer = function (host, opt) {
    opt = opt || {};
    var mode = opt.mode || 'parallelogram';
    var body = frame(host, opt.title || 'Drag the vertices',
      'Grab A, B or D and drag. C follows so the shape stays a ' + mode + '.');
    var svg = stage(body, '0 0 360 250', 460);
    var read = readoutBar(body, (opt.read || ['AB', 'DC', 'AD', 'BC', '∠A', '∠C', 'AC', 'BD', 'AO', 'OC']));
    var P = { A: [60, 200], B: [230, 200], D: [110, 70] };
    function C() { return [P.B[0] + P.D[0] - P.A[0], P.B[1] + P.D[1] - P.A[1]]; }
    function draw() {
      var A = P.A, B = P.B, Dp = P.D, Cp = C(), O = mid(A, Cp);
      svg.innerHTML = '';
      svg.appendChild(S('polygon', {
        points: [A, B, Cp, Dp].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      [[A, Cp, 'var(--brand)'], [B, Dp, 'var(--brass)']].forEach(function (g) {
        svg.appendChild(S('line', {
          x1: r1(g[0][0]), y1: r1(g[0][1]), x2: r1(g[1][0]), y2: r1(g[1][1]),
          stroke: g[2], 'stroke-width': 1.6
        }));
      });
      svg.appendChild(S('circle', { cx: r1(O[0]), cy: r1(O[1]), r: 3.6, fill: 'var(--brand)' }));
      var names = { A: A, B: B, C: Cp, D: Dp };
      var ctr = [(A[0] + B[0] + Cp[0] + Dp[0]) / 4, (A[1] + B[1] + Cp[1] + Dp[1]) / 4];
      var handles = [];
      Object.keys(names).forEach(function (k) {
        var p = names[k];
        var ux = (p[0] - ctr[0]), uy = (p[1] - ctr[1]), l = Math.hypot(ux, uy) || 1;
        svg.appendChild(S('text', {
          x: r1(p[0] + ux / l * 18), y: r1(p[1] + uy / l * 18), 'text-anchor': 'middle',
          'dominant-baseline': 'middle', 'font-family': 'Spectral, Georgia, serif',
          'font-size': 15, 'font-style': 'italic', fill: 'currentColor'
        }, k));
        var c = S('circle', {
          cx: r1(p[0]), cy: r1(p[1]), r: k === 'C' ? 4.5 : 8,
          fill: k === 'C' ? 'var(--muted)' : 'var(--brand)',
          'fill-opacity': k === 'C' ? 1 : .85
        });
        svg.appendChild(c);
        if (k !== 'C') handles.push({ id: k, node: c, get: function () { return P[k]; } });
      });
      draggable(svg, handles, function (id, x, y) {
        P[id] = [clamp(x, 24, 336), clamp(y, 24, 226)];
        if (mode === 'rhombus' && (id === 'B' || id === 'D')) {
          var L = dist(P.A, P.B);
          var u = [(P.D[0] - P.A[0]), (P.D[1] - P.A[1])], dl = Math.hypot(u[0], u[1]) || 1;
          P.D = [P.A[0] + u[0] / dl * L, P.A[1] + u[1] / dl * L];
        }
        draw();
      });
      var vals = { 'AB': r1(dist(A, B)), 'DC': r1(dist(Dp, Cp)), 'AD': r1(dist(A, Dp)),
        'BC': r1(dist(B, Cp)), '∠A': r1(angleDeg(A, B, Dp)) + '°', '∠C': r1(angleDeg(Cp, B, Dp)) + '°',
        '∠B': r1(angleDeg(B, A, Cp)) + '°', '∠D': r1(angleDeg(Dp, A, Cp)) + '°',
        'AC': r1(dist(A, Cp)), 'BD': r1(dist(B, Dp)),
        'AO': r1(dist(A, O)), 'OC': r1(dist(O, Cp)),
        'perimeter': r1(2 * (dist(A, B) + dist(A, Dp))) };
      Object.keys(read).forEach(function (k) { if (vals[k] != null) read[k].textContent = vals[k]; });
    }
    draw();
  };

  /* ============ 3. trapezium midline ============ */
  INT.trapeziumMidline = function (host, opt) {
    var body = frame(host, 'The midline of a trapezium',
      'Drag the top corners — the midline is always the average of the two bases.');
    var svg = stage(body, '0 0 380 250', 470);
    var read = readoutBar(body, ['a (AD)', 'b (BC)', '(a + b) / 2', 'MN measured']);
    var B = [110, 70], Cp = [240, 70];
    var A = [40, 200], Dp = [340, 200];
    function draw() {
      svg.innerHTML = '';
      svg.appendChild(S('polygon', {
        points: [A, B, Cp, Dp].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      var M = mid(A, B), N = mid(Dp, Cp);
      svg.appendChild(S('line', {
        x1: r1(M[0]), y1: r1(M[1]), x2: r1(N[0]), y2: r1(N[1]),
        stroke: 'var(--brass)', 'stroke-width': 3
      }));
      [[M, 'M'], [N, 'N']].forEach(function (g) {
        svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 4, fill: 'var(--brass)' }));
        svg.appendChild(S('text', {
          x: r1(g[0][0] + (g[1] === 'M' ? -16 : 16)), y: r1(g[0][1]), 'text-anchor': 'middle',
          'dominant-baseline': 'middle', 'font-family': 'Spectral, Georgia, serif',
          'font-size': 14, 'font-style': 'italic', fill: 'var(--brass)'
        }, g[1]));
      });
      var handles = [];
      [['B', B], ['C', Cp], ['A', A], ['D', Dp]].forEach(function (g) {
        var top = g[0] === 'B' || g[0] === 'C';
        var c = S('circle', { cx: r1(g[1][0]), cy: r1(g[1][1]), r: 8, fill: 'var(--brand)', 'fill-opacity': .85 });
        svg.appendChild(c);
        svg.appendChild(S('text', {
          x: r1(g[1][0]), y: r1(g[1][1] + (top ? -18 : 20)), 'text-anchor': 'middle',
          'font-family': 'Spectral, Georgia, serif', 'font-size': 14, 'font-style': 'italic',
          fill: 'currentColor'
        }, g[0]));
        handles.push({ id: g[0], node: c, get: function () { return g[1]; } });
      });
      draggable(svg, handles, function (id, x) {
        x = clamp(x, 20, 360);
        if (id === 'B') B[0] = Math.min(x, Cp[0] - 20);
        else if (id === 'C') Cp[0] = Math.max(x, B[0] + 20);
        else if (id === 'A') A[0] = Math.min(x, Dp[0] - 20);
        else Dp[0] = Math.max(x, A[0] + 20);
        draw();
      });
      var a = dist(A, Dp), b = dist(B, Cp);
      read['a (AD)'].textContent = r1(a);
      read['b (BC)'].textContent = r1(b);
      read['(a + b) / 2'].textContent = r1((a + b) / 2);
      read['MN measured'].textContent = r1(dist(M, N));
    }
    draw();
  };

  /* ============ 4. midline of a triangle ============ */
  INT.triangleMidline = function (host, opt) {
    var body = frame(host, 'The midline of a triangle',
      'Drag any vertex. MN stays parallel to BC and exactly half its length.');
    var svg = stage(body, '0 0 360 250', 460);
    var read = readoutBar(body, ['BC', 'MN', 'BC / MN']);
    var P = { A: [180, 40], B: [50, 205], C: [310, 205] };
    function draw() {
      svg.innerHTML = '';
      var M = mid(P.A, P.B), N = mid(P.A, P.C);
      svg.appendChild(S('polygon', {
        points: [P.A, P.B, P.C].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      svg.appendChild(S('line', {
        x1: r1(M[0]), y1: r1(M[1]), x2: r1(N[0]), y2: r1(N[1]),
        stroke: 'var(--brass)', 'stroke-width': 3
      }));
      var handles = [];
      ['A', 'B', 'C'].forEach(function (k) {
        var p = P[k];
        var c = S('circle', { cx: r1(p[0]), cy: r1(p[1]), r: 8, fill: 'var(--brand)', 'fill-opacity': .85 });
        svg.appendChild(c);
        svg.appendChild(S('text', {
          x: r1(p[0]), y: r1(p[1] + (k === 'A' ? -18 : 22)), 'text-anchor': 'middle',
          'font-family': 'Spectral, Georgia, serif', 'font-size': 15, 'font-style': 'italic',
          fill: 'currentColor'
        }, k));
        handles.push({ id: k, node: c, get: function () { return P[k]; } });
      });
      [[M, 'M'], [N, 'N']].forEach(function (g) {
        svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 4, fill: 'var(--brass)' }));
        svg.appendChild(S('text', {
          x: r1(g[0][0] + (g[1] === 'M' ? -15 : 15)), y: r1(g[0][1]), 'text-anchor': 'middle',
          'dominant-baseline': 'middle', 'font-family': 'Spectral, Georgia, serif',
          'font-size': 13.5, 'font-style': 'italic', fill: 'var(--brass)'
        }, g[1]));
      });
      draggable(svg, handles, function (id, x, y) {
        P[id] = [clamp(x, 22, 338), clamp(y, 22, 228)]; draw();
      });
      var bc = dist(P.B, P.C), mn = dist(M, N);
      read['BC'].textContent = r1(bc);
      read['MN'].textContent = r1(mn);
      read['BC / MN'].textContent = r2(bc / mn);
    }
    draw();
  };

  /* ============ 5. Thales' theorem ============ */
  INT.thales = function (host, opt) {
    var body = frame(host, 'Thales’ theorem',
      'Change the angle and the spacing — equal cuts on one side stay equal on the other.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 400 250', 480);
    var read = readoutBar(body, ['OA₁', 'A₁A₂', 'OB₁', 'B₁B₂', 'OA₁ : OA₂', 'OB₁ : OB₂']);
    var deg = 38, sp = 88;
    function draw() {
      svg.innerHTML = '';
      var O = [40, 210], t = deg * Math.PI / 180;
      var u1 = [1, 0], u2 = [Math.cos(t), -Math.sin(t)];
      function Q(u, s) { return [O[0] + u[0] * s, O[1] + u[1] * s]; }
      [u1, u2].forEach(function (u) {
        var e = Q(u, 340);
        svg.appendChild(S('line', {
          x1: O[0], y1: O[1], x2: r1(e[0]), y2: r1(e[1]),
          stroke: 'currentColor', 'stroke-width': 2
        }));
      });
      var A = [], B = [], i;
      for (i = 1; i <= 3; i++) { A.push(Q(u1, sp * i)); B.push(Q(u2, sp * i)); }
      for (i = 0; i < 3; i++) {
        svg.appendChild(S('line', {
          x1: r1(A[i][0]), y1: r1(A[i][1]), x2: r1(B[i][0]), y2: r1(B[i][1]),
          stroke: 'var(--brand)', 'stroke-width': 2
        }));
        [[A[i], 'A' + (i + 1), 18], [B[i], 'B' + (i + 1), -16]].forEach(function (g) {
          svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 4, fill: 'var(--brand)' }));
          svg.appendChild(S('text', {
            x: r1(g[0][0] + (g[2] > 0 ? 0 : -14)), y: r1(g[0][1] + (g[2] > 0 ? 18 : -8)),
            'text-anchor': 'middle', 'font-family': 'Spectral, Georgia, serif', 'font-size': 13,
            'font-style': 'italic', fill: 'currentColor'
          }, g[1]));
        });
      }
      svg.appendChild(S('circle', { cx: O[0], cy: O[1], r: 4, fill: 'currentColor' }));
      svg.appendChild(S('text', {
        x: O[0] - 14, y: O[1] + 6, 'font-family': 'Spectral, Georgia, serif',
        'font-size': 14, 'font-style': 'italic', fill: 'currentColor'
      }, 'O'));
      read['OA₁'].textContent = r1(sp);
      read['A₁A₂'].textContent = r1(sp);
      read['OB₁'].textContent = r1(sp);
      read['B₁B₂'].textContent = r1(sp);
      read['OA₁ : OA₂'].textContent = '1 : 2';
      read['OB₁ : OB₂'].textContent = '1 : 2';
    }
    slider(row, 'angle', 15, 70, deg, 1, function (v) { deg = v; draw(); });
    slider(row, 'spacing', 55, 105, sp, 1, function (v) { sp = v; draw(); });
    draw();
  };

  /* ============ 6. hyperbola y = k/x ============ */
  INT.hyperbola = function (host, opt) {
    var body = frame(host, 'The graph of y = k ⁄ x',
      'Change k and move the point — the product x·y never changes.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 340 300', 430);
    var read = readoutBar(body, ['k', 'x', 'y = k/x', 'x · y', 'quadrants']);
    var k = 6, px = 2;
    function draw() {
      svg.innerHTML = '';
      var cx = 170, cy = 150, u = 23, i;
      for (i = -6; i <= 6; i++) {
        svg.appendChild(S('line', { x1: cx + i * u, y1: 8, x2: cx + i * u, y2: 292, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
        svg.appendChild(S('line', { x1: 8, y1: cy + i * u, x2: 332, y2: cy + i * u, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      }
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 332, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 292, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      function branch(sg) {
        var dd = '', on = false;
        for (var x = 0.2; x <= 7; x += 0.04) {
          var y = k / x; if (Math.abs(y) > 6.3) continue;
          var X = cx + sg * x * u, Y = cy - sg * y * u;
          if (X < 6 || X > 334) continue;
          dd += (on ? 'L' : 'M') + r1(X) + ' ' + r1(Y) + ' '; on = true;
        }
        svg.appendChild(S('path', { d: dd, fill: 'none', stroke: 'var(--brand)', 'stroke-width': 2.6, 'stroke-linecap': 'round' }));
      }
      branch(1); branch(-1);
      var y0 = k / px, PX = cx + px * u, PY = cy - y0 * u;
      if (Math.abs(y0) <= 6.3) {
        svg.appendChild(S('line', { x1: r1(PX), y1: r1(PY), x2: r1(PX), y2: cy, stroke: 'var(--brass)', 'stroke-width': 1.4, 'stroke-dasharray': '4 4' }));
        svg.appendChild(S('line', { x1: r1(PX), y1: r1(PY), x2: cx, y2: r1(PY), stroke: 'var(--brass)', 'stroke-width': 1.4, 'stroke-dasharray': '4 4' }));
        svg.appendChild(S('rect', {
          x: r1(Math.min(cx, PX)), y: r1(Math.min(cy, PY)),
          width: r1(Math.abs(PX - cx)), height: r1(Math.abs(PY - cy)),
          fill: 'var(--brass)', 'fill-opacity': .13
        }));
        svg.appendChild(S('circle', { cx: r1(PX), cy: r1(PY), r: 5.5, fill: 'var(--brass)' }));
      }
      svg.appendChild(S('text', { x: 328, y: cy - 10, 'text-anchor': 'end', 'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--muted)' }, 'x'));
      svg.appendChild(S('text', { x: cx + 12, y: 18, 'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--muted)' }, 'y'));
      read['k'].textContent = k;
      read['x'].textContent = r2(px);
      read['y = k/x'].textContent = r2(k / px);
      read['x · y'].textContent = r2(px * (k / px));
      read['quadrants'].textContent = k > 0 ? 'I and III' : 'II and IV';
    }
    slider(row, 'k', -8, 8, k, 1, function (v) { if (v === 0) v = 1; k = v; draw(); });
    slider(row, 'x', 0.5, 6, px, 0.1, function (v) { px = v; draw(); });
    draw();
  };

  /* ============ 7. cancelling an algebraic fraction ============ */
  INT.fractionCancel = function (host, opt) {
    opt = opt || {};
    var items = opt.items || [];
    var body = frame(host, (opt && opt.title) || 'Cancelling step by step',
      (opt && opt.hint) || 'Pick a task, then reveal one step at a time.');
    var row = ctrlRow(body);
    var out = el('div', {}); body.appendChild(out);
    var idx = 0, shown = 0;
    var sel = el('select', { 'class': 'btn sm', style: 'padding:6px 10px' });
    items.forEach(function (it, i) { var o = el('option', { value: i }); o.innerHTML = it.title; sel.appendChild(o); });
    sel.addEventListener('change', function () { idx = +sel.value; shown = 0; render(); });
    row.appendChild(sel);
    var next = el('button', { 'class': 'btn sm primary', type: 'button' }); next.textContent = 'Next step →';
    var reset = el('button', { 'class': 'btn sm', type: 'button' }); reset.textContent = 'Restart';
    next.addEventListener('click', function () { if (shown < items[idx].steps.length) shown++; render(); });
    reset.addEventListener('click', function () { shown = 0; render(); });
    row.appendChild(next); row.appendChild(reset);
    function render() {
      var it = items[idx];
      var h = '<div class="eq boxed">' + it.start + '</div><ol class="steps">';
      it.steps.forEach(function (s, i) {
        h += '<li' + (i < shown ? '' : ' hidden') + '>' + s[0] +
          (s[1] ? '<span class="why">' + s[1] + '</span>' : '') + '</li>';
      });
      h += '</ol>';
      if (shown >= it.steps.length) h += '<div class="keybox"><div class="klabel">Answer</div>' + it.answer + '</div>';
      out.innerHTML = h;
      next.disabled = shown >= it.steps.length;
    }
    render();
  };

  /* ============ 8. lowest common denominator builder ============ */
  INT.lcdBuilder = function (host, opt) {
    opt = opt || {};
    var items = opt.items || [];
    var body = frame(host, (opt && opt.title) || 'Building the common denominator',
      (opt && opt.hint) || 'Choose a pair of denominators and watch the LCD being assembled.');
    var row = ctrlRow(body);
    var out = el('div', {}); body.appendChild(out);
    var idx = 0;
    var sel = el('select', { 'class': 'btn sm', style: 'padding:6px 10px' });
    items.forEach(function (it, i) { var o = el('option', { value: i }); o.innerHTML = it.label; sel.appendChild(o); });
    sel.addEventListener('change', function () { idx = +sel.value; render(); });
    row.appendChild(sel);
    function render() {
      var it = items[idx];
      out.innerHTML =
        '<table style="width:100%;border-collapse:collapse">' +
        '<tr><th>Denominator</th><th>Factorised</th><th>Extra factor needed</th></tr>' +
        it.rows.map(function (r) {
          return '<tr><td class="m">' + r[0] + '</td><td class="m">' + r[1] +
            '</td><td class="m" style="color:var(--brass)">' + r[2] + '</td></tr>';
        }).join('') + '</table>' +
        '<div class="keybox"><div class="klabel">Lowest common denominator</div>' +
        '<div class="eq" style="margin:.3em 0">' + it.lcd + '</div>' +
        (it.note ? '<p class="small" style="margin:8px 0 0">' + it.note + '</p>' : '') + '</div>';
    }
    render();
  };

  /* ============ 9. substitute a value / domain check ============ */
  /* Substitute a value into an expression and read the result. A `den` is
     optional: supply one for a fraction, and the model shows the denominator
     and refuses the values that make it zero. Without one it is simply an
     evaluator, which is what most topics want. */
  INT.substitute = function (host, opt) {
    opt = opt || {};
    var lab = opt.label || 'x';
    var body = frame(host, opt.title || 'Try a value of ' + lab,
      opt.hint || (opt.den
        ? 'Move ' + lab + '. Where the denominator hits zero the fraction has no value at all.'
        : 'Move ' + lab + ' and watch the value follow.'));
    var row = ctrlRow(body);
    var out = el('div', {}); body.appendChild(out);
    var f = opt.f || function () { return 0; };
    var den = opt.den, bad = opt.bad || [];
    var x = opt.start == null ? 2 : opt.start;
    function render() {
      var dv = den ? den(x) : 1;
      var ok = Math.abs(dv) > 1e-9;
      out.innerHTML = '<div class="eq boxed">' + (opt.expr || '') + '</div>' +
        '<div class="readout">' +
        '<div class="rd">' + lab + ' <b>' + r2(x) + '</b></div>' +
        (den ? '<div class="rd">denominator <b>' + r2(dv) + '</b></div>' : '') +
        '<div class="rd">value <b style="color:' + (ok ? 'var(--easy)' : 'var(--hard)') + '">' +
        (ok ? r2(f(x)) : 'undefined') + '</b></div></div>' +
        (ok ? (opt.note ? '<p class="small" style="margin:8px 0 0">' + opt.note + '</p>' : '')
            : '<div class="warn"><span class="wl">Not allowed</span>The denominator is 0, so the fraction has no value here. That is why we write ' + lab + ' \u2260 ' + bad.join(', ' + lab + ' \u2260 ') + '.</div>');
    }
    slider(row, lab, opt.min == null ? -6 : opt.min, opt.max == null ? 6 : opt.max, x,
      opt.step == null ? 0.5 : opt.step, function (v) { x = v; render(); });
    render();
  };

  /* ============ 10. instant-check quiz ============ */
  INT.quiz = function (host, opt) {
    var qs = (opt && opt.items) || [];
    var body = frame(host, (opt && opt.title) || 'Check yourself',
      (opt && opt.hint) || 'One click per question. Answers explain themselves.');
    var wrapEl = el('div', { 'class': 'quiz' });
    var score = el('p', { 'class': 'small' });
    var right = 0, done = 0;
    qs.forEach(function (q) {
      var item = el('div', { 'class': 'qitem' });
      item.innerHTML = '<div class="qq">' + q.q + '</div>';
      var opts = el('div', { 'class': 'opts' });
      var fb = el('div', { 'class': 'qfb' });
      q.a.forEach(function (txt, i) {
        var b = el('button', { 'class': 'opt', type: 'button' });
        b.innerHTML = txt;
        b.addEventListener('click', function () {
          if (item.dataset.done) return;
          item.dataset.done = '1'; done++;
          [].forEach.call(opts.children, function (o, j) {
            o.disabled = true;
            if (j === q.c) o.classList.add('ok');
            else if (o === b) o.classList.add('no');
          });
          if (i === q.c) right++;
          fb.innerHTML = (i === q.c ? '<b style="color:var(--easy)">Correct.</b> ' :
            '<b style="color:var(--hard)">Not quite.</b> ') + (q.why || '');
          fb.classList.add('on');
          score.textContent = right + ' of ' + done + ' correct' + (done === qs.length ? ' — all questions answered.' : '.');
        });
        opts.appendChild(b);
      });
      item.appendChild(opts); item.appendChild(fb);
      wrapEl.appendChild(item);
    });
    body.appendChild(wrapEl); body.appendChild(score);
  };


  /* ============ 11. triangle angles — drag and watch the sum ============ */
  INT.triangleAngles = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'The angles of a triangle',
      'Drag any vertex. The three angles change — their sum never does.');
    var svg = stage(body, '0 0 360 250', 460);
    var read = readoutBar(body, ['∠A', '∠B', '∠C', 'sum', 'longest side', 'largest angle']);
    var P = { A: [180, 38], B: [56, 208], C: [304, 208] };
    function draw() {
      svg.innerHTML = '';
      svg.appendChild(S('polygon', {
        points: [P.A, P.B, P.C].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      var cols = { A: 'var(--brand)', B: 'var(--brass)', C: 'var(--hard)' };
      var order = { A: ['B', 'C'], B: ['A', 'C'], C: ['A', 'B'] };
      var handles = [];
      ['A', 'B', 'C'].forEach(function (k) {
        var v = P[k], o = order[k];
        var a1 = Math.atan2(P[o[0]][1] - v[1], P[o[0]][0] - v[0]);
        var a2 = Math.atan2(P[o[1]][1] - v[1], P[o[1]][0] - v[0]);
        var dd = a2 - a1; while (dd > Math.PI) dd -= 2 * Math.PI; while (dd < -Math.PI) dd += 2 * Math.PI;
        var R = 26;
        var s1 = [v[0] + R * Math.cos(a1), v[1] + R * Math.sin(a1)];
        var e1 = [v[0] + R * Math.cos(a1 + dd), v[1] + R * Math.sin(a1 + dd)];
        svg.appendChild(S('path', {
          d: 'M' + r1(s1[0]) + ' ' + r1(s1[1]) + ' A' + R + ' ' + R + ' 0 0 ' + (dd > 0 ? 1 : 0) +
            ' ' + r1(e1[0]) + ' ' + r1(e1[1]),
          fill: 'none', stroke: cols[k], 'stroke-width': 2
        }));
        var mA = a1 + dd / 2;
        svg.appendChild(S('text', {
          x: r1(v[0] + 42 * Math.cos(mA)), y: r1(v[1] + 42 * Math.sin(mA)), 'text-anchor': 'middle',
          'dominant-baseline': 'middle', 'font-family': 'IBM Plex Mono, monospace',
          'font-size': 11.5, fill: cols[k]
        }, r1(angleDeg(v, P[o[0]], P[o[1]])) + '°'));
        var c = S('circle', { cx: r1(v[0]), cy: r1(v[1]), r: 8, fill: cols[k], 'fill-opacity': .9 });
        svg.appendChild(c);
        svg.appendChild(S('text', {
          x: r1(v[0]), y: r1(v[1] + (k === 'A' ? -18 : 24)), 'text-anchor': 'middle',
          'font-family': 'Spectral, Georgia, serif', 'font-size': 15, 'font-style': 'italic',
          fill: 'currentColor'
        }, k));
        handles.push({ id: k, node: c, get: function () { return P[k]; } });
      });
      draggable(svg, handles, function (id, x, y) {
        P[id] = [clamp(x, 24, 336), clamp(y, 24, 226)]; draw();
      });
      var a = angleDeg(P.A, P.B, P.C), b = angleDeg(P.B, P.A, P.C), c2 = angleDeg(P.C, P.A, P.B);
      read['∠A'].textContent = r1(a) + '°';
      read['∠B'].textContent = r1(b) + '°';
      read['∠C'].textContent = r1(c2) + '°';
      read['sum'].textContent = Math.round(a + b + c2) + '°';
      var sides = [['BC', dist(P.B, P.C), 'A'], ['AC', dist(P.A, P.C), 'B'], ['AB', dist(P.A, P.B), 'C']];
      sides.sort(function (x, y2) { return y2[1] - x[1]; });
      read['longest side'].textContent = sides[0][0];
      read['largest angle'].textContent = '∠' + sides[0][2];
    }
    draw();
  };


  /* ============ 12. right-triangle trigonometry ============ */
  INT.rightTriangle = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Solve the right triangle',
      'Change the angle or a side; every ratio and every length follows.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 380 250', 470);
    var read = readoutBar(body, ['α', 'β', 'a (opposite)', 'b (adjacent)', 'c (hyp)',
      'sin α', 'cos α', 'tan α', 'a² + b²', 'c²']);
    var alpha = 36, c = 190;
    function draw() {
      svg.innerHTML = '';
      var t = alpha * Math.PI / 180;
      var a = c * Math.sin(t), bb = c * Math.cos(t);
      var A = [40, 40], C0 = [40, 40 + a], B = [40 + bb, 40 + a];
      var sc = Math.min(300 / Math.max(bb, 1), 180 / Math.max(a, 1), 1);
      A = [40, 40]; C0 = [40, 40 + a * sc]; B = [40 + bb * sc, 40 + a * sc];
      svg.appendChild(S('polygon', {
        points: [A, B, C0].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      var rr = 13;
      svg.appendChild(S('path', {
        d: 'M' + r1(C0[0] + rr) + ' ' + r1(C0[1]) + ' L' + r1(C0[0] + rr) + ' ' + r1(C0[1] - rr) +
          ' L' + r1(C0[0]) + ' ' + r1(C0[1] - rr), fill: 'none', stroke: 'var(--brand)', 'stroke-width': 1.8
      }));
      var R = 34;
      svg.appendChild(S('path', {
        d: 'M' + r1(A[0]) + ' ' + r1(A[1] + R) + ' A' + R + ' ' + R + ' 0 0 0 ' +
          r1(A[0] + R * Math.sin(t)) + ' ' + r1(A[1] + R * Math.cos(t)),
        fill: 'none', stroke: 'var(--brass)', 'stroke-width': 2
      }));
      [[A, 'A', -6, -12], [B, 'B', 16, 6], [C0, 'C', -14, 16]].forEach(function (g) {
        svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 4, fill: 'currentColor' }));
        svg.appendChild(S('text', {
          x: r1(g[0][0] + g[2]), y: r1(g[0][1] + g[3]), 'text-anchor': 'middle',
          'font-family': 'Spectral, Georgia, serif', 'font-size': 15, 'font-style': 'italic',
          fill: 'currentColor'
        }, g[1]));
      });
      function lab(p, q, txt, dx, dy, col) {
        svg.appendChild(S('text', {
          x: r1((p[0] + q[0]) / 2 + dx), y: r1((p[1] + q[1]) / 2 + dy), 'text-anchor': 'middle',
          'font-family': 'IBM Plex Mono, monospace', 'font-size': 11.5, fill: col || 'var(--muted)'
        }, txt));
      }
      lab(A, C0, 'b = ' + r1(bb), -22, 0);
      lab(C0, B, 'a = ' + r1(a), 0, 20);
      lab(A, B, 'c = ' + r1(c), 22, -8, 'var(--brand)');
      svg.appendChild(S('text', {
        x: r1(A[0] + 44), y: r1(A[1] + 30), 'font-family': 'IBM Plex Mono, monospace',
        'font-size': 11.5, fill: 'var(--brass)'
      }, alpha + '°'));
      read['α'].textContent = alpha + '°';
      read['β'].textContent = (90 - alpha) + '°';
      read['a (opposite)'].textContent = r1(a);
      read['b (adjacent)'].textContent = r1(bb);
      read['c (hyp)'].textContent = r1(c);
      read['sin α'].textContent = r2(Math.sin(t));
      read['cos α'].textContent = r2(Math.cos(t));
      read['tan α'].textContent = r2(Math.tan(t));
      read['a² + b²'].textContent = Math.round(a * a + bb * bb);
      read['c²'].textContent = Math.round(c * c);
    }
    slider(row, 'angle α', 10, 80, alpha, 1, function (v) { alpha = v; draw(); });
    slider(row, 'hypotenuse c', 100, 240, c, 5, function (v) { c = v; draw(); });
    draw();
  };

  /* ============ 13. Pythagoras check ============ */
  INT.pythagoras = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'a² + b² = c²',
      'Change the legs. The two coloured squares always fill the third exactly.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 400 320', 460);
    var read = readoutBar(body, ['a', 'b', 'c', 'a²', 'b²', 'a² + b²', 'c²']);
    var a = 80, bb = 60;
    function draw() {
      svg.innerHTML = '';
      var k = 1.0, C0 = [160, 190], B = [160 + a * k, 190], A = [160, 190 - bb * k];
      svg.appendChild(S('rect', {
        x: r1(C0[0]), y: r1(C0[1]), width: r1(a * k), height: r1(a * k),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 1.5
      }));
      svg.appendChild(S('rect', {
        x: r1(C0[0] - bb * k), y: r1(C0[1] - bb * k), width: r1(bb * k), height: r1(bb * k),
        fill: 'var(--easy-tint)', stroke: 'currentColor', 'stroke-width': 1.5
      }));
      var ux = (B[0] - A[0]), uy = (B[1] - A[1]), L = Math.hypot(ux, uy);
      var px = uy / L, py = -ux / L;
      var P1 = [A[0] + px * L, A[1] + py * L], P2 = [B[0] + px * L, B[1] + py * L];
      svg.appendChild(S('polygon', {
        points: [A, B, P2, P1].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brass-tint)', stroke: 'currentColor', 'stroke-width': 1.8, 'stroke-linejoin': 'round'
      }));
      svg.appendChild(S('polygon', {
        points: [A, B, C0].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--surface)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      svg.appendChild(S('text', {
        x: r1(C0[0] + a * k / 2), y: r1(C0[1] + a * k / 2), 'text-anchor': 'middle',
        'dominant-baseline': 'middle', 'font-family': 'IBM Plex Mono, monospace',
        'font-size': 12, fill: 'var(--brand)'
      }, 'a² = ' + a * a));
      svg.appendChild(S('text', {
        x: r1(C0[0] - bb * k / 2), y: r1(C0[1] - bb * k / 2), 'text-anchor': 'middle',
        'dominant-baseline': 'middle', 'font-family': 'IBM Plex Mono, monospace',
        'font-size': 12, fill: 'var(--easy)'
      }, 'b² = ' + bb * bb));
      svg.appendChild(S('text', {
        x: r1((A[0] + P2[0]) / 2), y: r1((A[1] + P2[1]) / 2), 'text-anchor': 'middle',
        'dominant-baseline': 'middle', 'font-family': 'IBM Plex Mono, monospace',
        'font-size': 12, fill: 'var(--brass)'
      }, 'c² = ' + (a * a + bb * bb)));
      read['a'].textContent = a; read['b'].textContent = bb;
      read['c'].textContent = r2(Math.sqrt(a * a + bb * bb));
      read['a²'].textContent = a * a; read['b²'].textContent = bb * bb;
      read['a² + b²'].textContent = a * a + bb * bb;
      read['c²'].textContent = a * a + bb * bb;
    }
    slider(row, 'leg a', 40, 110, a, 5, function (v) { a = v; draw(); });
    slider(row, 'leg b', 30, 90, bb, 5, function (v) { bb = v; draw(); });
    draw();
  };

/* ============ 13b. Pythagoras — the full lab (Grade 8, geo-15 only) ============
     Five panels behind one tab strip: build the squares, the rearrangement
     proof, the similar-triangles proof, Garfield's trapezium, and a 3-D
     ladder scene. Registered under its own name so the plain right-angle
     check used elsewhere (Grade 9, and the "test a triangle" topic in this
     same grade) is untouched. */
  /* types `text` into el one character at a time; respects prefers-reduced-motion */
  function typeWrite(elNode, text, speed) {
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    elNode.textContent = '';
    if (reduce) { elNode.textContent = text; return; }
    var caret = document.createElement('span');
    caret.className = 'ptype-caret';
    elNode.appendChild(caret);
    var i = 0;
    (function tick() {
      if (i <= text.length) {
        elNode.textContent = text.slice(0, i);
        elNode.appendChild(caret);
        i++;
        setTimeout(tick, speed || 18);
      } else {
        caret.remove();
      }
    })();
  }

  INT.pythagorasLab = function (host, opt) {
    host.innerHTML = '';
    host.className = 'ilab plab plab-full';
    var hero = el('div', { 'class': 'phero' });
    hero.innerHTML =
      '<span class="pheroEyebrow">Grade 8 · Geometry · the most famous relation in mathematics</span>' +
      '<div class="pheroEq">a<sup>2</sup> + b<sup>2</sup> = c<sup>2</sup></div>' +
      '<p class="pheroSub"></p>';
    var toolsRow = el('div', { 'class': 'ptools' });
    var fsBtn = el('button', { type: 'button', 'class': 'pfs' }, ['⛶ Full screen']);
    toolsRow.appendChild(fsBtn);
    var tabsRow = el('div', { 'class': 'ptabs ptabsBig' });
    var progress = el('div', { 'class': 'pprog' });
    var body = el('div', { 'class': 'ib ibFull' });
    host.appendChild(hero); host.appendChild(toolsRow); host.appendChild(tabsRow); host.appendChild(progress); host.appendChild(body);

    typeWrite(hero.querySelector('.pheroSub'),
      'Five ways to see why it must be true — build it, prove it three different ways, then take it into space.', 16);

    function isFs() { return document.fullscreenElement === host; }
    function syncFsBtn() { fsBtn.innerHTML = isFs() ? '⤢ Exit full screen' : '⛶ Full screen'; }
    fsBtn.addEventListener('click', function () {
      if (isFs()) {
        if (document.exitFullscreen) document.exitFullscreen();
      } else if (host.requestFullscreen) {
        host.requestFullscreen();
      }
    });
    document.addEventListener('fullscreenchange', function () {
      host.classList.toggle('pfs-on', isFs());
      syncFsBtn();
    });

    var PANELS = [
      { id: 'build', label: 'See it', fn: panelBuild },
      { id: 'rearrange', label: 'Prove it · rearrange', fn: panelRearrange },
      { id: 'similar', label: 'Prove it · similar triangles', fn: panelSimilar },
      { id: 'garfield', label: 'Prove it · Garfield’s trapezium', fn: panelGarfield },
      { id: 'space', label: 'Into space', fn: panelSpace }
    ];
    var btns = {}, panes = {};
    PANELS.forEach(function (p) {
      var b = el('button', { type: 'button', 'class': 'ptab' }, [p.label]);
      b.addEventListener('click', function () { show(p.id); });
      tabsRow.appendChild(b);
      btns[p.id] = b;
    });
    function show(id) {
      var ix = PANELS.map(function (p) { return p.id; }).indexOf(id);
      PANELS.forEach(function (p) {
        btns[p.id].classList.toggle('on', p.id === id);
        if (panes[p.id]) panes[p.id].style.display = p.id === id ? '' : 'none';
      });
      progress.innerHTML = PANELS.map(function (p, i) {
        return '<span class="pdot' + (i === ix ? ' on' : i < ix ? ' done' : '') + '"></span>';
      }).join('') + '<span class="pcount">' + (ix + 1) + ' of ' + PANELS.length + '</span>';
      if (!panes[id]) {
        var pane = el('div', { 'class': 'ppane' });
        body.appendChild(pane);
        panes[id] = pane;
        PANELS.filter(function (p) { return p.id === id; })[0].fn(pane);
      }
    }

    /* ---------- panel 1: see it ---------- */
    function panelBuild(pane) {
      var row = ctrlRow(pane);
      var svg = stage(pane, '0 0 380 300', 720);
      var read = readoutBar(pane, ['a', 'b', 'c', 'a²', 'b²', 'c²']);
      var st = { a: 6, b: 8 };
      var O = [118, 236], SC = 15.5;
      function toScr(p) { return [O[0] + p[0] * SC, O[1] - p[1] * SC]; }
      function ptsAttr(poly) { return poly.map(toScr).map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '); }
      function draw() {
        svg.innerHTML = '';
        var a = st.a, b = st.b, c = Math.hypot(a, b);
        var P0 = [0, 0], P1 = [a, 0], P2 = [0, b];
        var sqA = [P0, P1, [a, -a], [0, -a]];
        var sqB = [P0, P2, [-b, b], [-b, 0]];
        var sqC = [P1, P2, [b, a + b], [a + b, a]];
        function square(poly, col) {
          svg.appendChild(S('polygon', { points: ptsAttr(poly), fill: col, 'fill-opacity': .45, stroke: col, 'stroke-width': 1.6 }));
        }
        square(sqA, 'var(--brand)'); square(sqB, 'var(--easy)'); square(sqC, 'var(--brass)');
        svg.appendChild(S('polygon', { points: ptsAttr([P0, P1, P2]), fill: 'var(--surface)', stroke: 'currentColor', 'stroke-width': 2 }));
        function centerLabel(poly, text, col) {
          var cx = poly.reduce(function (s, q) { return s + q[0]; }, 0) / poly.length;
          var cy = poly.reduce(function (s, q) { return s + q[1]; }, 0) / poly.length;
          var sp = toScr([cx, cy]);
          svg.appendChild(S('text', {
            x: r1(sp[0]), y: r1(sp[1]), 'text-anchor': 'middle', 'dominant-baseline': 'central',
            'font-family': 'IBM Plex Mono, monospace', 'font-size': 13, 'font-weight': 600, fill: col
          }, text));
        }
        centerLabel(sqA, String(a * a), 'var(--brand)');
        centerLabel(sqB, String(b * b), 'var(--easy)');
        centerLabel(sqC, String(a * a + b * b), 'var(--brass)');
        var hA = S('circle', { r: 6, fill: 'var(--brand)', stroke: 'var(--surface)', 'stroke-width': 2 });
        var hB = S('circle', { r: 6, fill: 'var(--easy)', stroke: 'var(--surface)', 'stroke-width': 2 });
        var sA = toScr(P1), sB = toScr(P2);
        hA.setAttribute('cx', r1(sA[0])); hA.setAttribute('cy', r1(sA[1]));
        hB.setAttribute('cx', r1(sB[0])); hB.setAttribute('cy', r1(sB[1]));
        svg.appendChild(hA); svg.appendChild(hB);
        draggable(svg, [
          { id: 'a', node: hA, get: function () { return toScr(P1); } },
          { id: 'b', node: hB, get: function () { return toScr(P2); } }
        ], function (id, x, y) {
          if (id === 'a') st.a = clamp(Math.round((x - O[0]) / SC), 3, 10);
          else st.b = clamp(Math.round((O[1] - y) / SC), 3, 10);
          sliders.a.set(st.a); sliders.b.set(st.b);
          draw();
        });
        read['a'].textContent = a; read['b'].textContent = b; read['c'].textContent = r2(c);
        read['a²'].textContent = a * a; read['b²'].textContent = b * b; read['c²'].textContent = a * a + b * b;
      }
      var sliders = {};
      sliders.a = slider(row, 'leg a', 3, 10, st.a, 1, function (v) { st.a = v; draw(); });
      sliders.b = slider(row, 'leg b', 3, 10, st.b, 1, function (v) { st.b = v; draw(); });
      var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
      pane.appendChild(hint);
      typeWrite(hint, 'Drag the two coloured handles, or use the sliders — the squares and the readout stay exact.', 14);
      draw();
    }

    /* ---------- panel 2: rearrange ---------- */
    function panelRearrange(pane) {
      var row = ctrlRow(pane);
      var svg = stage(pane, '0 0 300 300', 640);
      var st = { a: 6, b: 8 }, proved = [false, false, false, false];
      function fitRigid(src, dst) {
        var p0 = src[0], p1 = src[1], p2 = src[2], q0 = dst[0], q1 = dst[1], q2 = dst[2];
        var ux = p1[0] - p0[0], uy = p1[1] - p0[1], vx = p2[0] - p0[0], vy = p2[1] - p0[1];
        var det = ux * vy - uy * vx;
        var ia = vy / det, ib = -vx / det, ic = -uy / det, id = ux / det;
        var sx = q1[0] - q0[0], sy = q1[1] - q0[1], tx2 = q2[0] - q0[0], ty2 = q2[1] - q0[1];
        var m11 = sx * ia + tx2 * ic, m12 = sx * ib + tx2 * id;
        var m21 = sy * ia + ty2 * ic, m22 = sy * ib + ty2 * id;
        var tx = q0[0] - (m11 * p0[0] + m12 * p0[1]), ty = q0[1] - (m21 * p0[0] + m22 * p0[1]);
        return [m11, m21, m12, m22, tx, ty];
      }
      var tris, A, B, sqCel, sqAel, sqBel;
      function build() {
        var a = st.a, b = st.b, s = a + b;
        A = [[[0, 0], [a, 0], [0, b]], [[s, 0], [s, a], [a, 0]], [[s, s], [b, s], [s, a]], [[0, s], [0, b], [b, s]]];
        B = [[[s, b], [s, s], [a, b]], [[a, s], [a, b], [s, s]], [[a, 0], [0, 0], [a, b]], [[0, b], [a, b], [0, 0]]];
        var sqC = [[a, 0], [s, a], [b, s], [0, b]];
        var sqA = [[0, b], [a, b], [a, s], [0, s]];
        var sqB = [[a, 0], [s, 0], [s, b], [a, b]];
        svg.innerHTML = '';
        var pad = s * 0.1;
        svg.setAttribute('viewBox', (-pad) + ' ' + (-pad) + ' ' + (s + 2 * pad) + ' ' + (s + 2 * pad));
        var g = S('g', { transform: 'scale(1,-1) translate(0,-' + s + ')' });
        svg.appendChild(g);
        function poly(pts, cls) { return pts.map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '); }
        g.appendChild(S('rect', { x: 0, y: 0, width: s, height: s, fill: 'none', stroke: 'var(--rule)', 'stroke-width': 1.4, 'stroke-dasharray': '4 4', 'vector-effect': 'non-scaling-stroke' }));
        sqCel = S('polygon', { points: poly(sqC), fill: 'var(--brass)', 'fill-opacity': .5, stroke: 'var(--brass)', 'stroke-width': 1.6, 'vector-effect': 'non-scaling-stroke' });
        sqAel = S('polygon', { points: poly(sqA), fill: 'var(--brand)', 'fill-opacity': .4, stroke: 'var(--brand)', 'stroke-width': 1.6, 'vector-effect': 'non-scaling-stroke', opacity: 0 });
        sqBel = S('polygon', { points: poly(sqB), fill: 'var(--easy)', 'fill-opacity': .4, stroke: 'var(--easy)', 'stroke-width': 1.6, 'vector-effect': 'non-scaling-stroke', opacity: 0 });
        [sqCel, sqAel, sqBel].forEach(function (e) { e.style.transition = 'opacity .8s ease'; g.appendChild(e); });
        var cols = ['var(--brand)', 'var(--easy)', 'var(--brass)', 'var(--ink-soft)'];
        tris = A.map(function (tri, i) {
          var p = S('path', {
            d: 'M' + tri.map(function (q) { return r1(q[0]) + ' ' + r1(q[1]); }).join(' L') + ' Z',
            fill: cols[i], 'fill-opacity': .25, stroke: cols[i], 'stroke-width': 1.6,
            'vector-effect': 'non-scaling-stroke', style: 'cursor:pointer;transition:transform 1.1s cubic-bezier(.65,0,.35,1)'
          });
          p.addEventListener('click', function () { setTri(i, !proved[i]); });
          g.appendChild(p);
          return p;
        });
        applyAll();
      }
      function setTri(i, on) {
        proved[i] = on;
        tris[i].style.transform = on ? 'matrix(' + fitRigid(A[i], B[i]).join(',') + ')' : 'none';
        var any = proved.some(Boolean), all = proved.every(Boolean);
        sqCel.style.opacity = all ? 0 : 1;
        sqAel.style.opacity = all ? .4 : 0;
        sqBel.style.opacity = all ? .4 : 0;
        steps.forEach(function (el2, j) { el2.classList.toggle('show', all); });
        playBtn.textContent = all ? 'Reset' : 'Rearrange →';
      }
      function applyAll() { proved.forEach(function (on, i) { setTri(i, on); }); }
      var steps = [];
      function playAll() {
        var allOn = proved.every(Boolean);
        proved.forEach(function (_, i) { setTimeout(function () { setTri(i, !allOn); }, allOn ? 0 : i * 180); });
      }
      var playBtn = el('button', { type: 'button', 'class': 'btn sm' }, ['Rearrange →']);
      playBtn.addEventListener('click', playAll);
      row.appendChild(playBtn);
      slider(row, 'leg a', 3, 10, st.a, 1, function (v) { st.a = v; proved = [false, false, false, false]; build(); refreshSteps(); });
      slider(row, 'leg b', 3, 10, st.b, 1, function (v) { st.b = v; proved = [false, false, false, false]; build(); refreshSteps(); });
      var stepsWrap = el('div', { 'class': 'psteps' });
      pane.appendChild(stepsWrap);
      function refreshSteps() {
        var a = st.a, b = st.b, s = a + b, c2 = a * a + b * b;
        stepsWrap.innerHTML =
          '<p class="step">(a + b)² = 4·½ab + c² &nbsp; <span class="mono">' + (s * s) + ' = ' + (2 * a * b) + ' + ' + c2 + '</span></p>' +
          '<p class="step">a² + 2ab + b² = 2ab + c²</p>' +
          '<p class="step final">a² + b² = c² &nbsp; <span class="mono">' + (a * a) + ' + ' + (b * b) + ' = ' + c2 + '</span></p>';
        steps = [].slice.call(stepsWrap.querySelectorAll('.step'));
      }
      var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
      pane.appendChild(hint);
      typeWrite(hint, 'Click “Rearrange”, or click any one of the four triangles to move just that one.', 14);
      build(); refreshSteps();
    }

    /* ---------- panel 3: similar triangles ---------- */
    function panelSimilar(pane) {
      var row = ctrlRow(pane);
      var svg = stage(pane, '0 0 380 220', 720);
      var read = readoutBar(pane, ['a² = c·q', 'b² = c·p', 'a² + b²']);
      var st = { a: 7, b: 9 }, which = 'all';
      var btnRow = el('div', { 'class': 'ptabs sub' });
      [['all', 'Whole △ABC'], ['left', '△ACH'], ['right', '△CBH']].forEach(function (p) {
        var b = el('button', { type: 'button', 'class': 'ptab' }, [p[1]]);
        b.addEventListener('click', function () { which = p[0]; draw(); });
        b.dataset.id = p[0];
        btnRow.appendChild(b);
      });
      pane.appendChild(btnRow);
      function draw() {
        [].forEach.call(btnRow.children, function (b) { b.classList.toggle('on', b.dataset.id === which); });
        svg.innerHTML = '';
        var a = st.a, b = st.b, c = Math.hypot(a, b);
        var ox = 36, oy = 184, k = 300 / c;
        var A = [ox, oy], Bp = [ox + c * k, oy];
        var p = b * b / c, h = a * b / c;
        var H = [ox + p * k, oy], C = [ox + p * k, oy - h * k];
        function poly(pts) { return pts.map(function (q) { return r1(q[0]) + ',' + r1(q[1]); }).join(' '); }
        var big = S('polygon', { points: poly([A, Bp, C]), fill: 'none', stroke: 'var(--ink-soft)', 'stroke-width': which === 'all' ? 2.6 : 1.4 });
        var left = S('polygon', { points: poly([A, H, C]), fill: 'var(--brand)', 'fill-opacity': which === 'left' ? .35 : .12, stroke: 'var(--brand)', 'stroke-width': which === 'left' ? 2.4 : 1.2 });
        var right = S('polygon', { points: poly([C, H, Bp]), fill: 'var(--brass)', 'fill-opacity': which === 'right' ? .35 : .12, stroke: 'var(--brass)', 'stroke-width': which === 'right' ? 2.4 : 1.2 });
        svg.appendChild(left); svg.appendChild(right); svg.appendChild(big);
        svg.appendChild(S('line', { x1: r1(C[0]), y1: r1(C[1]), x2: r1(H[0]), y2: r1(H[1]), stroke: 'var(--ink)', 'stroke-width': 1.4, 'stroke-dasharray': '3 3' }));
        var rr = 10;
        svg.appendChild(S('path', { d: 'M' + r1(H[0] - rr) + ' ' + r1(H[1]) + ' L' + r1(H[0] - rr) + ' ' + r1(H[1] - rr) + ' L' + r1(H[0]) + ' ' + r1(H[1] - rr), fill: 'none', stroke: 'var(--ink-soft)', 'stroke-width': 1.4 }));
        [[A, 'A', -10, 16], [Bp, 'B', 10, 16], [C, 'C', 0, -10], [H, 'H', 0, 18]].forEach(function (g) {
          svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 3.4, fill: 'currentColor' }));
          svg.appendChild(S('text', { x: r1(g[0][0] + g[2]), y: r1(g[0][1] + g[3]), 'text-anchor': 'middle', 'font-family': 'Spectral,Georgia,serif', 'font-style': 'italic', 'font-size': 14, fill: 'currentColor' }, g[1]));
        });
        read['a² = c·q'].textContent = (a * a) + ' = ' + r1(c) + '·' + r1(c - p) + ' = ' + Math.round(c * (c - p));
        read['b² = c·p'].textContent = (b * b) + ' = ' + r1(c) + '·' + r1(p) + ' = ' + Math.round(c * p);
        read['a² + b²'].textContent = (a * a + b * b) + ' = c² = ' + Math.round(c * c);
      }
      slider(row, 'leg a (CB)', 4, 11, st.a, 1, function (v) { st.a = v; draw(); });
      slider(row, 'leg b (CA)', 4, 11, st.b, 1, function (v) { st.b = v; draw(); });
      var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
      pane.appendChild(hint);
      typeWrite(hint, 'The altitude from the right angle splits the triangle into two smaller triangles, each similar to the whole. Choose one above to see its relation.', 14);
      draw();
    }

    /* ---------- panel 4: Garfield's trapezium ---------- */
    function panelGarfield(pane) {
      var row = ctrlRow(pane);
      var svg = stage(pane, '0 0 340 260', 700);
      var st = { a: 5, b: 8 };
      var noteEl = el('div', { 'class': 'keybox', style: 'margin-top:14px' });
      pane.appendChild(noteEl);
      function draw() {
        svg.innerHTML = '';
        var a = st.a, b = st.b, c = Math.hypot(a, b);
        var k = 230 / (a + b);
        var ox = 55, oy = 230;
        function scr(p) { return [ox + p[0] * k, oy - p[1] * k]; }
        var W = [0, 0], Z = [0, a], P = [b, 0], X = [a + b, 0], Y = [a + b, b];
        function poly(pts) { return pts.map(scr).map(function (q) { return r1(q[0]) + ',' + r1(q[1]); }).join(' '); }
        svg.appendChild(S('polygon', { points: poly([W, Z, Y, X]), fill: 'var(--surface-2)', stroke: 'var(--ink-soft)', 'stroke-width': 1.6 }));
        svg.appendChild(S('polygon', { points: poly([W, Z, P]), fill: 'var(--brand)', 'fill-opacity': .3, stroke: 'var(--brand)', 'stroke-width': 1.4 }));
        svg.appendChild(S('polygon', { points: poly([P, X, Y]), fill: 'var(--easy)', 'fill-opacity': .3, stroke: 'var(--easy)', 'stroke-width': 1.4 }));
        svg.appendChild(S('polygon', { points: poly([Z, P, Y]), fill: 'var(--brass)', 'fill-opacity': .3, stroke: 'var(--brass)', 'stroke-width': 1.4 }));
        [[W, 'W'], [Z, 'Z'], [P, 'P'], [X, 'X'], [Y, 'Y']].forEach(function (g) {
          var s = scr(g[0]);
          svg.appendChild(S('circle', { cx: r1(s[0]), cy: r1(s[1]), r: 3.2, fill: 'currentColor' }));
          svg.appendChild(S('text', { x: r1(s[0]), y: r1(s[1] - 9), 'text-anchor': 'middle', 'font-family': 'Spectral,Georgia,serif', 'font-style': 'italic', 'font-size': 13, fill: 'currentColor' }, g[1]));
        });
        var a2b2 = a * a + b * b, trapArea = (a + b) * (a + b) / 2, sumArea = a * b + (a * a + b * b) / 2;
        noteEl.innerHTML = '<div class="klabel">Same area, counted two ways</div>' +
          '<p style="margin:0 0 6px">As a trapezium: <span class="mono">½(a+b)(a+b) = ' + r1(trapArea) + '</span></p>' +
          '<p style="margin:0 0 6px">As three triangles: <span class="mono">½ab + ½ab + ½c² = ' + r1(sumArea) + '</span></p>' +
          '<p style="margin:0;font-weight:600;color:var(--brand)">so a² + b² = c² &nbsp; (' + (a * a) + ' + ' + (b * b) + ' = ' + a2b2 + ')</p>';
      }
      slider(row, 'leg a', 3, 9, st.a, 1, function (v) { st.a = v; draw(); });
      slider(row, 'leg b', 3, 9, st.b, 1, function (v) { st.b = v; draw(); });
      var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
      pane.appendChild(hint);
      typeWrite(hint, 'Two congruent right triangles (teal, green) and one isosceles right triangle (gold) tile the trapezium W–Z–Y–X exactly.', 14);
      draw();
    }

    /* ---------- panel 5: into space ---------- */
    function panelSpace(pane) {
      var row = ctrlRow(pane);
      var svg = stage(pane, '0 0 380 280', 760);
      var read = readoutBar(pane, ['ladder c', 'foot from wall', 'height up the wall']);
      var st = { len: 10, foot: 6 }, view = { yaw: -0.55, pitch: .42, zoom: 1 };
      function P(x, y, z) {
        var cy = Math.cos(view.yaw), sy = Math.sin(view.yaw);
        var rx = x * cy + z * sy, rz = -x * sy + z * cy;
        var ox = 190, oy = 230, sc = 15.5 * view.zoom;
        return [ox + rx * sc, oy - y * sc - rz * sc * view.pitch];
      }
      function ln(a, b, col, w, dash) {
        var o = { x1: r1(a[0]), y1: r1(a[1]), x2: r1(b[0]), y2: r1(b[1]), stroke: col, 'stroke-width': w };
        if (dash) o['stroke-dasharray'] = dash;
        svg.appendChild(S('line', o));
      }
      function draw() {
        svg.innerHTML = '';
        var len = st.len, foot = Math.min(st.foot, len - 1);
        var height = Math.sqrt(len * len - foot * foot);
        for (var i = -2; i <= 6; i++) ln(P(i, 0, -3), P(i, 0, 3), 'var(--rule)', 1);
        for (var j = -3; j <= 3; j++) ln(P(-2, 0, j), P(6, 0, j), 'var(--rule)', 1);
        ln(P(0, 0, -3), P(0, 6.5, -3), 'var(--rule-soft)', 1.4);
        ln(P(0, 0, 3), P(0, 6.5, 3), 'var(--rule-soft)', 1.4);
        ln(P(0, 6.5, -3), P(0, 6.5, 3), 'var(--rule-soft)', 1.4);
        ln(P(0, 0, 0), P(0, height, 0), 'var(--brand)', 2.6);
        ln(P(0, 0, 0), P(foot, 0, 0), 'var(--brass)', 2.4, '4 3');
        ln(P(0, height, 0), P(foot, 0, 0), 'var(--hard)', 3.4);
        [[0, height, 0], [foot, 0, 0], [0, 0, 0]].forEach(function (p) {
          var s = P(p[0], p[1], p[2]);
          svg.appendChild(S('circle', { cx: r1(s[0]), cy: r1(s[1]), r: 4, fill: 'var(--ink)' }));
        });
        var hs = P(0, height / 2, 0), fs = P(foot / 2, 0, 0), ls = P(foot / 2, height / 2, 0);
        svg.appendChild(S('text', { x: r1(hs[0] - 14), y: r1(hs[1]), 'font-family': 'IBM Plex Mono,monospace', 'font-size': 11.5, fill: 'var(--brand)' }, r2(height) + ' m'));
        svg.appendChild(S('text', { x: r1(fs[0]), y: r1(fs[1] + 18), 'text-anchor': 'middle', 'font-family': 'IBM Plex Mono,monospace', 'font-size': 11.5, fill: 'var(--brass)' }, foot + ' m'));
        svg.appendChild(S('text', { x: r1(ls[0] + 10), y: r1(ls[1] - 6), 'font-family': 'IBM Plex Mono,monospace', 'font-size': 11.5, fill: 'var(--hard)' }, len + ' m'));
        read['ladder c'].textContent = len + ' m'; read['foot from wall'].textContent = foot + ' m';
        read['height up the wall'].textContent = r2(height) + ' m';
      }
      slider(row, 'ladder length', 6, 15, st.len, 1, function (v) { st.len = v; draw(); });
      slider(row, 'foot from wall', 2, 14, st.foot, 1, function (v) { st.foot = v; draw(); });
      (function enableDrag() {
        var dragging = false, lastX = 0, lastY = 0;
        svg.style.cursor = 'grab'; svg.style.touchAction = 'none';
        svg.style.userSelect = 'none'; svg.style.webkitUserSelect = 'none';
        svg.addEventListener('pointerdown', function (e) { dragging = true; lastX = e.clientX; lastY = e.clientY; svg.setPointerCapture(e.pointerId); svg.style.cursor = 'grabbing'; });
        svg.addEventListener('pointermove', function (e) {
          if (!dragging) return;
          view.yaw = clamp(view.yaw + (e.clientX - lastX) * 0.01, -1.4, 1.4);
          view.pitch = clamp(view.pitch + (e.clientY - lastY) * 0.006, .05, .95);
          lastX = e.clientX; lastY = e.clientY; draw();
        });
        svg.addEventListener('pointerup', function () { dragging = false; svg.style.cursor = 'grab'; });
        svg.addEventListener('pointercancel', function () { dragging = false; svg.style.cursor = 'grab'; });
        svg.addEventListener('wheel', function (e) {
          e.preventDefault();
          view.zoom = clamp(view.zoom - e.deltaY * 0.0012, .55, 2.1);
          draw();
        }, { passive: false });
      })();
      var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
      pane.appendChild(hint);
      typeWrite(hint, 'Drag to orbit, scroll to zoom. The wall, the ground and the ladder always meet in a right angle — that is what makes the theorem apply.', 14);
      draw();
    }

    show('build');
  };

  /* ============ 13b. the basic trigonometric identity, spun into a 3D cone ============
     Scoped to geo-17 (Grade 8, lesson 24) only. INT.rightTriangle, used by many other
     topics across grades 7-9, is left completely untouched. */
  INT.trigIdentity3D = function (host, opt) {
    var REDUCE = w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches;
    host.innerHTML = '';
    host.className = 'ilab tlab';

    var hero = el('div', { 'class': 'thero' });
    hero.innerHTML =
      '<span class="theroEyebrow">Grade 8 · Geometry · from Pythagoras to trigonometry</span>' +
      '<div class="theroEq">sin<sup>2</sup>α + cos<sup>2</sup>α = 1</div>' +
      '<p class="theroSub"></p>';
    host.appendChild(hero);
    typeWrite(hero.querySelector('.theroSub'),
      'Divide Pythagoras’ theorem by c² and the hypotenuse shrinks to 1 — the radius of a ' +
      'unit circle. Spin the triangle around its height and the same identity becomes a cone.', 14);

    var body = el('div', { 'class': 'ib tsplit' });
    host.appendChild(body);
    var leftPane = el('div', { 'class': 'tpane tpane-2d' });
    var rightPane = el('div', { 'class': 'tpane tpane-3d' });
    body.appendChild(leftPane); body.appendChild(rightPane);

    /* -------- shared state -------- */
    var st = { alpha: 40, disp: 40 };
    var view = { yaw: -0.5, pitch: .42, zoom: 1 };
    var lastInteract = 0, dragging = false;

    /* -------- left: the generating triangle + Pythagoras squares -------- */
    var lHead = el('div', { 'class': 'tph' });
    lHead.innerHTML = '<span class="tpt">The triangle</span><span class="tphint">Same shape, c shrunk to 1.</span>';
    leftPane.appendChild(lHead);
    var lRow = ctrlRow(leftPane);
    var aSlider = slider(lRow, 'angle α', 10, 80, st.alpha, 1, function (v) { st.alpha = v; lastInteract = performance.now(); drawDefs(); });
    var svg2 = stage(leftPane, '0 0 300 250', 400);
    var read2 = readoutBar(leftPane, ['α', 'sin α', 'cos α', 'sin²α + cos²α']);

    var barWrap = el('div', { 'class': 'tidbarwrap' });
    var barLabel = el('div', { 'class': 'tidbarlabel' }, ['always exactly one unit of area:']);
    var bar = el('div', { 'class': 'tidbar' });
    var barSin = el('div', { 'class': 'tidbarfill sinfill' });
    var barCos = el('div', { 'class': 'tidbarfill cosfill' });
    bar.appendChild(barSin); bar.appendChild(barCos);
    barWrap.appendChild(barLabel); barWrap.appendChild(bar);
    leftPane.appendChild(barWrap);

    function draw2D() {
      var t = st.disp * Math.PI / 180;
      var s = Math.sin(t) * 90, cLeg = Math.cos(t) * 90;
      var C = [90, 170], A = [90, 170 - s], R = [90 + cLeg, 170];
      svg2.innerHTML = '';
      function sq(p0, p1, p2, p3, color) {
        svg2.appendChild(S('polygon', {
          points: [p0, p1, p2, p3].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
          fill: color, opacity: .8
        }));
      }
      sq(C, A, [C[0] - s, C[1] - s], [C[0] - s, C[1]], 'var(--brand)');
      sq(C, R, [C[0] + cLeg, C[1] + cLeg], [C[0], C[1] + cLeg], 'var(--brass)');
      sq(A, R, [R[0] + s, R[1] - cLeg], [A[0] + s, A[1] - cLeg], 'var(--hard)');
      svg2.appendChild(S('polygon', {
        points: [C, A, R].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--surface)', stroke: 'currentColor', 'stroke-width': 2, 'stroke-linejoin': 'round'
      }));
      var ms = 10;
      svg2.appendChild(S('path', {
        d: 'M' + (C[0] + ms) + ' ' + C[1] + ' L' + (C[0] + ms) + ' ' + (C[1] - ms) + ' L' + C[0] + ' ' + (C[1] - ms),
        fill: 'none', stroke: 'var(--muted)', 'stroke-width': 1.4
      }));
      var R0 = 26, ang = Math.atan2(A[1] - R[1], A[0] - R[0]);
      svg2.appendChild(S('path', {
        d: 'M' + r1(R[0] - R0) + ' ' + r1(R[1]) + ' A' + R0 + ' ' + R0 + ' 0 0 0 ' +
          r1(R[0] + R0 * Math.cos(ang)) + ' ' + r1(R[1] + R0 * Math.sin(ang)),
        fill: 'none', stroke: 'var(--brass)', 'stroke-width': 2
      }));
      [[C, 'C'], [A, 'A'], [R, 'α', 1]].forEach(function (g) {
        svg2.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 3.5, fill: 'currentColor' }));
        svg2.appendChild(S('text', {
          x: r1(g[0][0] + (g[2] ? -18 : -10)), y: r1(g[0][1] + (g[2] ? 6 : -10)),
          'font-family': 'IBM Plex Mono,monospace', 'font-size': 12, fill: g[2] ? 'var(--brass)' : 'currentColor'
        }, g[1]));
      });
      var sinV = Math.sin(t), cosV = Math.cos(t);
      read2['α'].textContent = r1(st.disp) + '°';
      read2['sin α'].textContent = r2(sinV);
      read2['cos α'].textContent = r2(cosV);
      read2['sin²α + cos²α'].textContent = r2(sinV * sinV + cosV * cosV);
      barSin.style.flexBasis = (sinV * sinV * 100) + '%';
      barCos.style.flexBasis = (cosV * cosV * 100) + '%';
    }

    /* -------- right: the same triangle, spun into a cone -------- */
    var rHead = el('div', { 'class': 'tph' });
    rHead.innerHTML = '<span class="tpt">Spin it into a cone</span>';
    var spinBtn = el('button', { type: 'button', 'class': 'pbtn' }, ['Spin ↻']);
    rHead.appendChild(spinBtn);
    rightPane.appendChild(rHead);
    var svg3 = stage(rightPane, '0 0 380 300', 640);
    var read3 = readoutBar(rightPane, ['radius = cos α', 'height = sin α', 'slant']);

    function P(x, y, z) {
      var cy = Math.cos(view.yaw), sy = Math.sin(view.yaw);
      var rx = x * cy + z * sy, rz = -x * sy + z * cy;
      var ox = 190, oy = 230, sc = 100 * view.zoom;
      return [ox + rx * sc, oy - y * sc - rz * sc * view.pitch];
    }
    function draw3D() {
      var t = st.disp * Math.PI / 180;
      var radius = Math.cos(t), height = Math.sin(t);
      svg3.innerHTML = '';
      var N = 48, basePts = [];
      for (var i = 0; i <= N; i++) {
        var a2 = (i / N) * Math.PI * 2;
        basePts.push(P(radius * Math.cos(a2), 0, radius * Math.sin(a2)));
      }
      var apex = P(0, height, 0), centerPt = P(0, 0, 0);
      var frontPt = P(radius, 0, 0);

      [Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4, Math.PI, 5 * Math.PI / 4, 3 * Math.PI / 2, 7 * Math.PI / 4].forEach(function (a3) {
        var bp = P(radius * Math.cos(a3), 0, radius * Math.sin(a3));
        svg3.appendChild(S('line', {
          x1: r1(apex[0]), y1: r1(apex[1]), x2: r1(bp[0]), y2: r1(bp[1]),
          stroke: 'var(--rule-soft)', 'stroke-width': 1
        }));
      });

      var minXi = 0, maxXi = 0;
      basePts.forEach(function (p, i) { if (p[0] < basePts[minXi][0]) minXi = i; if (p[0] > basePts[maxXi][0]) maxXi = i; });
      svg3.appendChild(S('path', { d: 'M' + basePts.map(function (p) { return r1(p[0]) + ' ' + r1(p[1]); }).join(' L'), fill: 'none', stroke: 'var(--muted)', 'stroke-width': 1.6 }));
      svg3.appendChild(S('line', { x1: r1(apex[0]), y1: r1(apex[1]), x2: r1(basePts[minXi][0]), y2: r1(basePts[minXi][1]), stroke: 'var(--ink)', 'stroke-width': 2 }));
      svg3.appendChild(S('line', { x1: r1(apex[0]), y1: r1(apex[1]), x2: r1(basePts[maxXi][0]), y2: r1(basePts[maxXi][1]), stroke: 'var(--ink)', 'stroke-width': 2 }));

      svg3.appendChild(S('polygon', {
        points: [apex, frontPt, centerPt].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--hard)', opacity: .3, stroke: 'var(--hard)', 'stroke-width': 2
      }));
      svg3.appendChild(S('line', { x1: r1(centerPt[0]), y1: r1(centerPt[1]), x2: r1(apex[0]), y2: r1(apex[1]), stroke: 'var(--brand)', 'stroke-width': 2.4 }));
      svg3.appendChild(S('line', { x1: r1(centerPt[0]), y1: r1(centerPt[1]), x2: r1(frontPt[0]), y2: r1(frontPt[1]), stroke: 'var(--brass)', 'stroke-width': 2.4, 'stroke-dasharray': '4 3' }));
      [centerPt, apex, frontPt].forEach(function (p) {
        svg3.appendChild(S('circle', { cx: r1(p[0]), cy: r1(p[1]), r: 4, fill: 'var(--ink)' }));
      });
      svg3.appendChild(S('text', {
        x: r1((centerPt[0] + apex[0]) / 2 - 16), y: r1((centerPt[1] + apex[1]) / 2), 'font-family': 'IBM Plex Mono,monospace',
        'font-size': 11.5, fill: 'var(--brand)'
      }, r2(height)));
      svg3.appendChild(S('text', {
        x: r1((centerPt[0] + frontPt[0]) / 2), y: r1((centerPt[1] + frontPt[1]) / 2 + 16), 'text-anchor': 'middle',
        'font-family': 'IBM Plex Mono,monospace', 'font-size': 11.5, fill: 'var(--brass)'
      }, r2(radius)));

      read3['radius = cos α'].textContent = r2(radius);
      read3['height = sin α'].textContent = r2(height);
      read3['slant'].textContent = '1.00';
    }

    var hint = el('p', { 'class': 'small', style: 'margin-top:10px' });
    rightPane.appendChild(hint);
    typeWrite(hint, 'Drag to orbit, scroll to zoom. The axis and the radius always meet in a right angle — that’s where this cone’s own Pythagoras check lives: slant² = height² + radius².', 12);

    (function enableDrag() {
      svg3.style.cursor = 'grab'; svg3.style.touchAction = 'none';
      svg3.style.userSelect = 'none'; svg3.style.webkitUserSelect = 'none';
      var lastX = 0, lastY = 0;
      svg3.addEventListener('pointerdown', function (e) { dragging = true; lastX = e.clientX; lastY = e.clientY; svg3.setPointerCapture(e.pointerId); svg3.style.cursor = 'grabbing'; lastInteract = performance.now(); });
      svg3.addEventListener('pointermove', function (e) {
        if (!dragging) return;
        view.yaw = clamp(view.yaw + (e.clientX - lastX) * 0.01, -2.4, 2.4);
        view.pitch = clamp(view.pitch + (e.clientY - lastY) * 0.006, .05, .95);
        lastX = e.clientX; lastY = e.clientY; lastInteract = performance.now();
      });
      svg3.addEventListener('pointerup', function () { dragging = false; svg3.style.cursor = 'grab'; });
      svg3.addEventListener('pointercancel', function () { dragging = false; svg3.style.cursor = 'grab'; });
      svg3.addEventListener('wheel', function (e) {
        e.preventDefault();
        view.zoom = clamp(view.zoom - e.deltaY * 0.0012, .55, 1.8);
        lastInteract = performance.now();
      }, { passive: false });
    })();

    var spinning = false;
    spinBtn.addEventListener('click', function () {
      if (spinning) return;
      spinning = true; lastInteract = performance.now();
      var start = performance.now(), from = view.yaw, dur = REDUCE ? 1 : 1300;
      (function tick(now) {
        var tt = Math.min(1, (now - start) / dur);
        var e = tt < .5 ? 2 * tt * tt : 1 - Math.pow(-2 * tt + 2, 2) / 2;
        view.yaw = from + e * Math.PI * 2;
        if (tt < 1) requestAnimationFrame(tick);
        else { spinning = false; lastInteract = performance.now(); }
      })(start);
    });

    /* -------- the four ratios (reference panel, full width) -------- */
    var defsSec = el('div', { 'class': 'tdefs' });
    defsSec.innerHTML = '<div class="tph"><span class="tpt">The four ratios</span>' +
      '<span class="tphint">All measured for the angle α at A.</span></div>';
    host.appendChild(defsSec);
    var defsBody = el('div', { 'class': 'tdefsBody' });
    defsSec.appendChild(defsBody);
    var dfigWrap = el('div', { 'class': 'tdefsFig' });
    var dsvg = S('svg', { viewBox: '0 0 300 210' });
    dfigWrap.appendChild(dsvg);
    defsBody.appendChild(dfigWrap);
    var cardsWrap = el('div', { 'class': 'tdefsCards' });
    defsBody.appendChild(cardsWrap);

    function ratioRow(sym, num, den, frac, hi) {
      var row = el('div', { 'class': 'tdrow' });
      row.dataset.hi = hi;
      row.innerHTML =
        '<span class="tdsym">' + sym + ' =</span>' +
        '<span class="tdfrac"><span class="tdnum">' + num + '</span><span class="tdden">' + den + '</span></span>' +
        '<span class="tdeq">=</span>' +
        '<span class="tdfrac tdfrac-letter"><span class="tdnum">' + frac[0] + '</span><span class="tdden">' + frac[1] + '</span></span>';
      return row;
    }
    var card1 = el('div', { 'class': 'tdcard' });
    card1.appendChild(ratioRow('sin α', 'opposite', 'hypotenuse', ['a', 'c'], 'a,c,alpha'));
    card1.appendChild(ratioRow('cos α', 'adjacent', 'hypotenuse', ['b', 'c'], 'b,c,alpha'));
    var card2 = el('div', { 'class': 'tdcard' });
    card2.appendChild(ratioRow('tan α', 'opposite', 'adjacent', ['a', 'b'], 'a,b,alpha'));
    card2.appendChild(ratioRow('cot α', 'adjacent', 'opposite', ['b', 'a'], 'a,b,alpha'));
    cardsWrap.appendChild(card1); cardsWrap.appendChild(card2);

    var segEls = {};
    function drawDefs() {
      var t = st.alpha * Math.PI / 180, L = 135;
      var aLeg = Math.sin(t) * L, bLeg = Math.cos(t) * L;
      var ox = 75, oy = 175;
      var C = [ox, oy], A = [ox, oy - bLeg], B = [ox + aLeg, oy];
      dsvg.innerHTML = '';
      segEls = {};
      segEls.b = S('line', { x1: r1(C[0]), y1: r1(C[1]), x2: r1(A[0]), y2: r1(A[1]), stroke: 'currentColor', 'stroke-width': 2, 'pathLength': 1 });
      segEls.a = S('line', { x1: r1(C[0]), y1: r1(C[1]), x2: r1(B[0]), y2: r1(B[1]), stroke: 'currentColor', 'stroke-width': 2, 'pathLength': 1 });
      segEls.c = S('line', { x1: r1(A[0]), y1: r1(A[1]), x2: r1(B[0]), y2: r1(B[1]), stroke: 'var(--hard)', 'stroke-width': 2.4, 'pathLength': 1 });
      ['b', 'a', 'c'].forEach(function (k) { dsvg.appendChild(segEls[k]); });
      var ms = 10;
      dsvg.appendChild(S('path', {
        d: 'M' + (C[0] + ms) + ' ' + C[1] + ' L' + (C[0] + ms) + ' ' + (C[1] - ms) + ' L' + C[0] + ' ' + (C[1] - ms),
        fill: 'none', stroke: 'var(--muted)', 'stroke-width': 1.3
      }));
      var R1 = 22, angA = Math.atan2(B[1] - A[1], B[0] - A[0]);
      segEls.alpha = S('path', {
        d: 'M' + r1(A[0]) + ' ' + r1(A[1] + R1) + ' A' + R1 + ' ' + R1 + ' 0 0 0 ' +
          r1(A[0] + R1 * Math.cos(angA)) + ' ' + r1(A[1] + R1 * Math.sin(angA)),
        fill: 'none', stroke: 'var(--brass)', 'stroke-width': 2
      });
      dsvg.appendChild(segEls.alpha);
      var R2 = 22, angB = Math.atan2(A[1] - B[1], A[0] - B[0]);
      segEls.beta = S('path', {
        d: 'M' + r1(B[0] - R2) + ' ' + r1(B[1]) + ' A' + R2 + ' ' + R2 + ' 0 0 1 ' +
          r1(B[0] + R2 * Math.cos(angB)) + ' ' + r1(B[1] + R2 * Math.sin(angB)),
        fill: 'none', stroke: 'var(--muted)', 'stroke-width': 1.6
      });
      dsvg.appendChild(segEls.beta);
      [[C, 'C', -12, 16], [A, 'A', -4, -12], [B, 'B', 10, 16]].forEach(function (g) {
        dsvg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: 3.5, fill: 'currentColor' }));
        dsvg.appendChild(S('text', {
          x: r1(g[0][0] + g[2]), y: r1(g[0][1] + g[3]), 'font-family': 'Spectral,Georgia,serif',
          'font-size': 14, 'font-style': 'italic', fill: 'currentColor'
        }, g[1]));
      });
      dsvg.appendChild(S('text', { x: r1(A[0] + 10), y: r1(A[1] + 14), 'font-size': 11, fill: 'var(--brass)' }, 'α'));
      dsvg.appendChild(S('text', { x: r1(B[0] - 16), y: r1(B[1] - 10), 'font-size': 11, fill: 'var(--muted)' }, 'β'));
      function lab(p, q, txt, sub, dx, dy, col) {
        var mx = (p[0] + q[0]) / 2 + dx, my = (p[1] + q[1]) / 2 + dy;
        dsvg.appendChild(S('text', { x: r1(mx), y: r1(my), 'text-anchor': 'middle', 'font-family': 'IBM Plex Mono,monospace', 'font-size': 12.5, fill: col }, txt));
        dsvg.appendChild(S('text', { x: r1(mx), y: r1(my + 13), 'text-anchor': 'middle', 'font-family': 'Inter,sans-serif', 'font-size': 10, fill: 'var(--muted)' }, sub));
      }
      lab(C, A, 'b', 'adj.', -22, -4, 'var(--brand)');
      lab(C, B, 'a', 'opposite', 0, 22, 'var(--brand)');
      lab(A, B, 'c', 'hyp.', 22, -2, 'var(--hard)');
    }
    function setHi(keys) {
      ['a', 'b', 'c', 'alpha', 'beta'].forEach(function (k) {
        var on = keys.indexOf(k) >= 0;
        if (!segEls[k]) return;
        segEls[k].style.strokeWidth = on ? (k === 'c' ? 4.4 : 3.8) : '';
        segEls[k].style.filter = on ? 'drop-shadow(0 0 3px currentColor)' : 'none';
        if (k === 'a' || k === 'b') segEls[k].style.stroke = on ? 'var(--brand)' : '';
        if (k === 'alpha') segEls[k].style.stroke = on ? 'var(--brass)' : 'var(--brass)';
      });
    }
    [].slice.call(cardsWrap.querySelectorAll('.tdrow')).forEach(function (row) {
      row.addEventListener('mouseenter', function () { setHi(row.dataset.hi.split(',')); });
      row.addEventListener('mouseleave', function () { setHi([]); });
      row.addEventListener('focus', function () { setHi(row.dataset.hi.split(',')); });
      row.addEventListener('blur', function () { setHi([]); });
      row.setAttribute('tabindex', '0');
    });

    if (!REDUCE && w.IntersectionObserver) {
      [dfigWrap, card1, card2].forEach(function (elx, i) {
        elx.style.opacity = 0; elx.style.transform = 'translateY(12px)';
        elx.style.transition = 'opacity .55s ease ' + (i * .14) + 's, transform .55s ease ' + (i * .14) + 's';
      });
      var seen = false;
      var io = new w.IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting && !seen) {
            seen = true;
            [dfigWrap, card1, card2].forEach(function (elx) { elx.style.opacity = 1; elx.style.transform = 'none'; });
            [].slice.call(dsvg.querySelectorAll('line, path')).forEach(function (ln, i) {
              ln.style.strokeDasharray = '1'; ln.style.strokeDashoffset = '1';
              ln.style.transition = 'stroke-dashoffset .5s ease ' + (i * .08) + 's';
              requestAnimationFrame(function () { requestAnimationFrame(function () { ln.style.strokeDashoffset = '0'; }); });
            });
            io.disconnect();
          }
        });
      }, { threshold: .3 });
      io.observe(defsSec);
    }

    drawDefs();

    function loop(now) {
      st.disp += (st.alpha - st.disp) * (REDUCE ? 1 : .14);
      if (!REDUCE && !dragging && !spinning && now - lastInteract > 2600) view.yaw += 0.0022;
      draw2D(); draw3D();
      requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);

    if (!REDUCE) {
      [leftPane, rightPane].forEach(function (p, i) {
        p.style.opacity = 0; p.style.transform = 'translateY(10px)';
        p.style.transition = 'opacity .5s ease ' + (i * .12) + 's, transform .5s ease ' + (i * .12) + 's';
        requestAnimationFrame(function () { requestAnimationFrame(function () { p.style.opacity = 1; p.style.transform = 'none'; }); });
      });
    }
  };

  /* ============ 14. inequality on a number line ============ */

  INT.inequalityLine = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Solutions on the number line',
      'Move the boundary and switch between strict and non-strict.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 400 120', 470);
    var read = readoutBar(body, ['inequality', 'boundary', 'x = 0 works?', 'x = 6 works?']);
    var b = 2, strict = true, dir = 'gt';
    function draw() {
      svg.innerHTML = '';
      var x0 = 30, x1 = 370, cx = function (v) { return x0 + (v + 8) / 16 * (x1 - x0); };
      svg.appendChild(S('line', { x1: x0, y1: 62, x2: x1, y2: 62, stroke: 'currentColor', 'stroke-width': 1.8 }));
      for (var v = -8; v <= 8; v += 2) {
        svg.appendChild(S('line', { x1: r1(cx(v)), y1: 57, x2: r1(cx(v)), y2: 67, stroke: 'var(--faint)', 'stroke-width': 1 }));
        svg.appendChild(S('text', {
          x: r1(cx(v)), y: 84, 'text-anchor': 'middle', 'font-family': 'IBM Plex Mono, monospace',
          'font-size': 10.5, fill: 'var(--muted)'
        }, String(v)));
      }
      var from = dir === 'gt' ? cx(b) : x0, to = dir === 'gt' ? x1 : cx(b);
      svg.appendChild(S('line', { x1: r1(from), y1: 62, x2: r1(to), y2: 62, stroke: 'var(--brand)', 'stroke-width': 6, 'stroke-linecap': 'butt' }));
      svg.appendChild(S('circle', {
        cx: r1(cx(b)), cy: 62, r: 7, fill: strict ? 'var(--paper)' : 'var(--brand)',
        stroke: 'var(--brand)', 'stroke-width': 2.4
      }));
      svg.appendChild(S('text', {
        x: 200, y: 28, 'text-anchor': 'middle', 'font-family': 'Spectral, Georgia, serif',
        'font-size': 16, 'font-style': 'italic', fill: 'var(--brand)'
      }, 'x ' + (dir === 'gt' ? (strict ? '>' : '≥') : (strict ? '<' : '≤')) + ' ' + b));
      var op = dir === 'gt'
        ? function (t) { return strict ? t > b : t >= b; }
        : function (t) { return strict ? t < b : t <= b; };
      read['inequality'].textContent = 'x ' + (dir === 'gt' ? (strict ? '>' : '≥') : (strict ? '<' : '≤')) + ' ' + b;
      read['boundary'].textContent = b + (strict ? ' (open)' : ' (closed)');
      read['x = 0 works?'].textContent = op(0) ? 'yes' : 'no';
      read['x = 6 works?'].textContent = op(6) ? 'yes' : 'no';
    }
    slider(row, 'boundary', -6, 6, b, 1, function (v) { b = v; draw(); });
    var t1 = el('button', { 'class': 'btn sm', type: 'button' }); t1.textContent = 'strict / not strict';
    t1.addEventListener('click', function () { strict = !strict; draw(); });
    var t2 = el('button', { 'class': 'btn sm', type: 'button' }); t2.textContent = 'flip < / >';
    t2.addEventListener('click', function () { dir = dir === 'gt' ? 'lt' : 'gt'; draw(); });
    row.appendChild(t1); row.appendChild(t2);
    draw();
  };

  /* ============ 15. roots and rational exponents ============ */
  INT.rootPower = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'A root is a power',
      'Pick a base and an index — the two notations always give the same number.');
    var row = ctrlRow(body);
    var out = el('div', {}); body.appendChild(out);
    var a = 64, n = 3, mm = 1;
    function render() {
      var root = Math.pow(a, mm / n);
      out.innerHTML =
        '<div class="eq boxed" style="text-align:center">' +
        '<span class="m"><sup>' + n + '</sup>√' + a + (mm > 1 ? '<sup>' + mm + '</sup>' : '') +
        '&nbsp; = &nbsp;' + a + '<sup>' + mm + '/' + n + '</sup>&nbsp; = &nbsp;' +
        '<b style="color:var(--brand)">' + (Math.abs(root - Math.round(root)) < 1e-9 ? Math.round(root) : r2(root)) +
        '</b></span></div>' +
        '<div class="readout">' +
        '<div class="rd">base a <b>' + a + '</b></div>' +
        '<div class="rd">index n <b>' + n + '</b></div>' +
        '<div class="rd">power m <b>' + mm + '</b></div>' +
        '<div class="rd">check: value<sup>' + n + '</sup> <b>' + r2(Math.pow(root, n)) + '</b></div>' +
        '<div class="rd">a<sup>' + mm + '</sup> <b>' + r2(Math.pow(a, mm)) + '</b></div></div>' +
        '<p class="small" style="margin:12px 0 0">Raising the answer to the power ' + n +
        ' gives back a<sup>' + mm + '</sup> — that is exactly what “root of degree ' + n + '” means.</p>';
    }
    slider(row, 'base a', 1, 100, a, 1, function (v) { a = v; render(); });
    slider(row, 'index n', 2, 6, n, 1, function (v) { n = v; render(); });
    slider(row, 'power m', 1, 6, mm, 1, function (v) { mm = v; render(); });
    render();
  };


  /* ============ 16. quadratic — roots and the discriminant ============ */
  INT.quadratic = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Roots and the discriminant',
      'Move a, b and c. Watch D decide how many times the curve meets the x-axis.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 280', 460);
    var read = readoutBar(body, ['a', 'b', 'c', 'D = b² − 4ac', 'roots', 'x₁', 'x₂', 'x₁ + x₂', 'x₁ · x₂']);
    var A = 1, B = -2, C = -3;
    function draw() {
      svg.innerHTML = '';
      var cx = 180, cy = 150, u = 20, i;
      for (i = -7; i <= 7; i++) {
        svg.appendChild(S('line', { x1: cx + i * u, y1: 8, x2: cx + i * u, y2: 272, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
        svg.appendChild(S('line', { x1: 8, y1: cy + i * u, x2: 352, y2: cy + i * u, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      }
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 272, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      var d = '', on = false;
      for (var x = -8.6; x <= 8.6; x += 0.04) {
        var y = A * x * x + B * x + C;
        if (y < -6.6 || y > 6.6) { on = false; continue; }
        var X = cx + x * u, Y = cy - y * u;
        if (X < 6 || X > 354) { on = false; continue; }
        d += (on ? 'L' : 'M') + r1(X) + ' ' + r1(Y) + ' '; on = true;
      }
      svg.appendChild(S('path', { d: d, fill: 'none', stroke: 'var(--brand)', 'stroke-width': 2.6, 'stroke-linecap': 'round' }));
      var D = B * B - 4 * A * C, r1v = null, r2v = null, n = 0;
      if (D > 0) { n = 2; r1v = (-B - Math.sqrt(D)) / (2 * A); r2v = (-B + Math.sqrt(D)) / (2 * A); }
      else if (D === 0) { n = 1; r1v = r2v = -B / (2 * A); }
      [r1v, r2v].forEach(function (r, k) {
        if (r == null || (k === 1 && n === 1)) return;
        svg.appendChild(S('circle', { cx: r1(cx + r * u), cy: cy, r: 5.5, fill: 'var(--brass)' }));
      });
      var vx = -B / (2 * A), vy = A * vx * vx + B * vx + C;
      if (Math.abs(vy) <= 6.6) svg.appendChild(S('circle', { cx: r1(cx + vx * u), cy: r1(cy - vy * u), r: 4, fill: 'var(--brand)' }));
      read['a'].textContent = A; read['b'].textContent = B; read['c'].textContent = C;
      read['D = b² − 4ac'].textContent = D;
      read['roots'].textContent = n === 2 ? 'two' : n === 1 ? 'one' : 'none';
      read['x₁'].textContent = r1v == null ? '—' : r2(r1v);
      read['x₂'].textContent = r2v == null ? '—' : r2(r2v);
      read['x₁ + x₂'].textContent = n ? r2(-B / A) : '—';
      read['x₁ · x₂'].textContent = n ? r2(C / A) : '—';
    }
    slider(row, 'a', -3, 3, A, 1, function (v) { if (v === 0) v = 1; A = v; draw(); });
    slider(row, 'b', -6, 6, B, 1, function (v) { B = v; draw(); });
    slider(row, 'c', -6, 6, C, 1, function (v) { C = v; draw(); });
    draw();
  };

  /* ============ 17. a point on the coordinate plane ============ */
  INT.coordPlane = function (host, opt) {
    opt = opt || {};
    var body = frame(host, opt.title || 'Two points on the plane',
      'Drag A or B. The distance and the midpoint follow.');
    var svg = stage(body, '0 0 360 300', 460);
    var read = readoutBar(body, ['A', 'B', 'x₂ − x₁', 'y₂ − y₁', 'distance AB', 'midpoint M']);
    var u = 26, cx = 180, cy = 150;
    var P = { A: [-3, -2], B: [3, 2] };
    function sx(v) { return cx + v * u; }
    function sy(v) { return cy - v * u; }
    function draw() {
      svg.innerHTML = '';
      var i;
      for (i = -6; i <= 6; i++) {
        svg.appendChild(S('line', { x1: sx(i), y1: 8, x2: sx(i), y2: 292, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
        svg.appendChild(S('line', { x1: 8, y1: sy(i), x2: 352, y2: sy(i), stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      }
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 292, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      var A = P.A, B = P.B;
      svg.appendChild(S('path', {
        d: 'M' + sx(A[0]) + ' ' + sy(A[1]) + ' L' + sx(B[0]) + ' ' + sy(A[1]) + ' L' + sx(B[0]) + ' ' + sy(B[1]),
        fill: 'none', stroke: 'var(--faint)', 'stroke-width': 1.4, 'stroke-dasharray': '5 4'
      }));
      svg.appendChild(S('line', { x1: sx(A[0]), y1: sy(A[1]), x2: sx(B[0]), y2: sy(B[1]), stroke: 'var(--brand)', 'stroke-width': 2.6 }));
      var M = [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2];
      svg.appendChild(S('circle', { cx: sx(M[0]), cy: sy(M[1]), r: 4.5, fill: 'var(--brass)' }));
      var handles = [];
      ['A', 'B'].forEach(function (k) {
        var p = P[k];
        var c = S('circle', { cx: sx(p[0]), cy: sy(p[1]), r: 8, fill: 'var(--brand)', 'fill-opacity': .9 });
        svg.appendChild(c);
        svg.appendChild(S('text', {
          x: sx(p[0]) + 15, y: sy(p[1]) - 12, 'font-family': 'Spectral, Georgia, serif',
          'font-size': 14, 'font-style': 'italic', fill: 'currentColor'
        }, k));
        handles.push({ id: k, node: c, get: function () { return [sx(P[k][0]), sy(P[k][1])]; } });
      });
      draggable(svg, handles, function (id, x, y) {
        var gx = Math.max(-6, Math.min(6, Math.round((x - cx) / u)));
        var gy = Math.max(-5, Math.min(5, Math.round((cy - y) / u)));
        P[id] = [gx, gy]; draw();
      });
      var dx = B[0] - A[0], dy = B[1] - A[1];
      read['A'].textContent = '(' + A[0] + ', ' + A[1] + ')';
      read['B'].textContent = '(' + B[0] + ', ' + B[1] + ')';
      read['x₂ − x₁'].textContent = dx;
      read['y₂ − y₁'].textContent = dy;
      read['distance AB'].textContent = r2(Math.hypot(dx, dy));
      read['midpoint M'].textContent = '(' + M[0] + ', ' + M[1] + ')';
    }
    draw();
  };

  /* ============ 18. vectors ============ */
  INT.vectors = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Adding vectors',
      'Drag the tips. The green vector is always a + b.');
    var svg = stage(body, '0 0 360 300', 460);
    var read = readoutBar(body, ['a', 'b', 'a + b', '| a |', '| b |', '| a + b |']);
    var u = 26, cx = 150, cy = 190;
    var V = { a: [3, 2], b: [2, -3] };
    function sx(v) { return cx + v * u; }
    function sy(v) { return cy - v * u; }
    function arrow(x1, y1, x2, y2, col, w) {
      var L = Math.hypot(x2 - x1, y2 - y1) || 1, ux = (x2 - x1) / L, uy = (y2 - y1) / L;
      svg.appendChild(S('line', { x1: r1(x1), y1: r1(y1), x2: r1(x2), y2: r1(y2), stroke: col, 'stroke-width': w || 2.6 }));
      svg.appendChild(S('path', {
        d: 'M' + r1(x2 - 12 * ux + 5.5 * uy) + ' ' + r1(y2 - 12 * uy - 5.5 * ux) + ' L' + r1(x2) + ' ' + r1(y2) +
          ' L' + r1(x2 - 12 * ux - 5.5 * uy) + ' ' + r1(y2 - 12 * uy + 5.5 * ux),
        fill: 'none', stroke: col, 'stroke-width': w || 2.6, 'stroke-linejoin': 'round'
      }));
    }
    function draw() {
      svg.innerHTML = '';
      var i;
      for (i = -5; i <= 7; i++) svg.appendChild(S('line', { x1: sx(i), y1: 8, x2: sx(i), y2: 292, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      for (i = -4; i <= 6; i++) svg.appendChild(S('line', { x1: 8, y1: sy(i), x2: 352, y2: sy(i), stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.5 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 292, stroke: 'var(--faint)', 'stroke-width': 1.5 }));
      var a = V.a, b = V.b, sum = [a[0] + b[0], a[1] + b[1]];
      arrow(cx, cy, sx(a[0]), sy(a[1]), 'var(--brand)');
      arrow(sx(a[0]), sy(a[1]), sx(sum[0]), sy(sum[1]), 'var(--brass)');
      arrow(cx, cy, sx(sum[0]), sy(sum[1]), 'var(--easy)', 3);
      var handles = [];
      [['a', a], ['b', sum]].forEach(function (g) {
        var c = S('circle', { cx: sx(g[1][0]), cy: sy(g[1][1]), r: 8, fill: g[0] === 'a' ? 'var(--brand)' : 'var(--brass)', 'fill-opacity': .85 });
        svg.appendChild(c);
        handles.push({ id: g[0], node: c, get: function () { return [sx(g[1][0]), sy(g[1][1])]; } });
      });
      draggable(svg, handles, function (id, x, y) {
        var gx = Math.max(-5, Math.min(7, Math.round((x - cx) / u)));
        var gy = Math.max(-4, Math.min(6, Math.round((cy - y) / u)));
        if (id === 'a') V.a = [gx, gy];
        else V.b = [gx - V.a[0], gy - V.a[1]];
        draw();
      });
      read['a'].textContent = '(' + a[0] + '; ' + a[1] + ')';
      read['b'].textContent = '(' + b[0] + '; ' + b[1] + ')';
      read['a + b'].textContent = '(' + sum[0] + '; ' + sum[1] + ')';
      read['| a |'].textContent = r2(Math.hypot(a[0], a[1]));
      read['| b |'].textContent = r2(Math.hypot(b[0], b[1]));
      read['| a + b |'].textContent = r2(Math.hypot(sum[0], sum[1]));
    }
    draw();
  };

  /* ============ 19. area of a triangle — same base, same height ============ */
  INT.areaModel = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Base and height decide the area',
      'Slide the apex along the top line. The area never changes.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 380 250', 460);
    var read = readoutBar(body, ['base a', 'height h', 'area ½ah', 'perimeter']);
    var base = 220, h = 120, apex = 0.5;
    function draw() {
      svg.innerHTML = '';
      var y0 = 200, x0 = 60;
      var B1 = [x0, y0], B2 = [x0 + base, y0], Ap = [x0 + apex * base, y0 - h];
      svg.appendChild(S('line', { x1: 20, y1: y0 - h, x2: 360, y2: y0 - h, stroke: 'var(--faint)', 'stroke-width': 1.3, 'stroke-dasharray': '5 4' }));
      svg.appendChild(S('polygon', {
        points: [B1, B2, Ap].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      svg.appendChild(S('line', { x1: r1(Ap[0]), y1: r1(Ap[1]), x2: r1(Ap[0]), y2: y0, stroke: 'var(--brass)', 'stroke-width': 1.6, 'stroke-dasharray': '4 3' }));
      svg.appendChild(S('text', { x: r1(Ap[0]) - 14, y: y0 - h / 2, 'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--brass)' }, 'h'));
      svg.appendChild(S('text', { x: x0 + base / 2, y: y0 + 18, 'text-anchor': 'middle', 'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--muted)' }, 'a'));
      var c = S('circle', { cx: r1(Ap[0]), cy: r1(Ap[1]), r: 8, fill: 'var(--brand)', 'fill-opacity': .9 });
      svg.appendChild(c);
      draggable(svg, [{ id: 'ap', node: c, get: function () { return Ap; } }], function (id, x) {
        apex = Math.max(-0.35, Math.min(1.35, (x - x0) / base)); draw();
      });
      var s1 = Math.hypot(Ap[0] - B1[0], h), s2 = Math.hypot(B2[0] - Ap[0], h);
      read['base a'].textContent = base;
      read['height h'].textContent = h;
      read['area ½ah'].textContent = base * h / 2;
      read['perimeter'].textContent = r1(base + s1 + s2);
    }
    slider(row, 'base', 120, 280, base, 10, function (v) { base = v; draw(); });
    slider(row, 'height', 50, 150, h, 5, function (v) { h = v; draw(); });
    draw();
  };

  /* ============ 20. circle angles ============ */
  INT.circleAngles = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'The inscribed angle',
      'Drag C round the circle. The inscribed angle stays half the central angle.');
    var svg = stage(body, '0 0 340 300', 440);
    var read = readoutBar(body, ['central ∠AOB', 'inscribed ∠ACB', 'ratio', 'arc AB']);
    var O = [170, 150], R = 112;
    var aA = 200, aB = 340, aC = 70;
    function pt(deg) { return [O[0] + R * Math.cos(deg * Math.PI / 180), O[1] + R * Math.sin(deg * Math.PI / 180)]; }
    function draw() {
      svg.innerHTML = '';
      var A = pt(aA), B = pt(aB), C = pt(aC);
      svg.appendChild(S('circle', { cx: O[0], cy: O[1], r: R, fill: 'none', stroke: 'currentColor', 'stroke-width': 2 }));
      svg.appendChild(S('path', {
        d: 'M' + r1(A[0]) + ' ' + r1(A[1]) + ' A' + R + ' ' + R + ' 0 0 1 ' + r1(B[0]) + ' ' + r1(B[1]),
        fill: 'none', stroke: 'var(--brass)', 'stroke-width': 5
      }));
      [[O, A], [O, B]].forEach(function (g) {
        svg.appendChild(S('line', { x1: g[0][0], y1: g[0][1], x2: r1(g[1][0]), y2: r1(g[1][1]), stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      });
      [[C, A], [C, B]].forEach(function (g) {
        svg.appendChild(S('line', { x1: r1(g[0][0]), y1: r1(g[0][1]), x2: r1(g[1][0]), y2: r1(g[1][1]), stroke: 'var(--brand)', 'stroke-width': 2.2 }));
      });
      [[O, 'O', 'var(--faint)'], [A, 'A', 'currentColor'], [B, 'B', 'currentColor'], [C, 'C', 'var(--brand)']].forEach(function (g) {
        svg.appendChild(S('circle', { cx: r1(g[0][0]), cy: r1(g[0][1]), r: g[1] === 'C' ? 8 : 4.5, fill: g[2] }));
        svg.appendChild(S('text', {
          x: r1(g[0][0] + (g[0][0] > O[0] ? 15 : -15)), y: r1(g[0][1] + (g[0][1] > O[1] ? 16 : -10)),
          'text-anchor': 'middle', 'font-family': 'Spectral, Georgia, serif', 'font-size': 14,
          'font-style': 'italic', fill: g[2]
        }, g[1]));
      });
      var Cnode = svg.querySelectorAll('circle')[svg.querySelectorAll('circle').length - 1];
      var handles = [{ id: 'C', node: svg.querySelectorAll('circle')[4], get: function () { return C; } }];
      draggable(svg, handles, function (id, x, y) {
        aC = Math.atan2(y - O[1], x - O[0]) * 180 / Math.PI;
        var lo = aA, hi = aB;
        var norm = (aC % 360 + 360) % 360;
        if (norm > 195 && norm < 345) aC = norm < 270 ? 195 : 345;   // keep C off the arc AB
        draw();
      });
      var central = 140;
      var ang2 = angleDeg(C, A, B);
      read['central ∠AOB'].textContent = central + '°';
      read['inscribed ∠ACB'].textContent = r1(ang2) + '°';
      read['ratio'].textContent = r2(central / Math.max(ang2, 0.001));
      read['arc AB'].textContent = central + '°';
    }
    draw();
  };

  /* ============ 21. transformations ============ */
  INT.transform = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Move the shape',
      'Choose a transformation and change its amount.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 300', 440);
    var read = readoutBar(body, ['transformation', 'lengths', 'angles', 'orientation']);
    var mode = 'translate', amount = 2;
    var u = 26, cx = 180, cy = 150;
    var SHAPE = [[1, 1], [4, 1], [2, 3]];
    function sx(v) { return cx + v * u; } function sy(v) { return cy - v * u; }
    function draw() {
      svg.innerHTML = '';
      var i;
      for (i = -6; i <= 6; i++) {
        svg.appendChild(S('line', { x1: sx(i), y1: 8, x2: sx(i), y2: 292, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
        svg.appendChild(S('line', { x1: 8, y1: sy(i), x2: 352, y2: sy(i), stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      }
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 292, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      var img = SHAPE.map(function (p) {
        if (mode === 'translate') return [p[0] - amount, p[1] - amount];
        if (mode === 'reflect') return [-p[0], p[1]];
        if (mode === 'rotate') return [-p[1], p[0]];
        return [p[0] * (amount / 2), p[1] * (amount / 2)];
      });
      svg.appendChild(S('polygon', {
        points: SHAPE.map(function (p) { return sx(p[0]) + ',' + sy(p[1]); }).join(' '),
        fill: 'var(--surface-2)', stroke: 'currentColor', 'stroke-width': 2, 'stroke-linejoin': 'round'
      }));
      svg.appendChild(S('polygon', {
        points: img.map(function (p) { return r1(sx(p[0])) + ',' + r1(sy(p[1])); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'var(--brand)', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      var names = { translate: 'translation', reflect: 'reflection in the y-axis', rotate: 'rotation 90° about O', enlarge: 'enlargement' };
      read['transformation'].textContent = names[mode];
      read['lengths'].textContent = mode === 'enlarge' ? '× ' + r2(amount / 2) : 'unchanged';
      read['angles'].textContent = 'unchanged';
      read['orientation'].textContent = mode === 'reflect' ? 'reversed' : 'kept';
    }
    ['translate', 'reflect', 'rotate', 'enlarge'].forEach(function (mname) {
      var b = el('button', { 'class': 'btn sm', type: 'button' });
      b.textContent = mname;
      b.addEventListener('click', function () { mode = mname; draw(); });
      row.appendChild(b);
    });
    slider(row, 'amount', 1, 4, amount, 1, function (v) { amount = v; draw(); });
    draw();
  };

  /* ============ 22. averages of a small data set ============ */
  INT.averages = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Mean, median and mode',
      'Change a value and watch which average moves.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 380 220', 460);
    var read = readoutBar(body, ['values', 'mean', 'median', 'mode', 'range']);
    var data = [3, 5, 5, 6, 8, 9, 12];
    var idx = 6;
    function draw() {
      svg.innerHTML = '';
      var x0 = 34, y0 = 170, w = 40, u = 11;
      data.forEach(function (v, i) {
        svg.appendChild(S('rect', {
          x: x0 + i * w, y: y0 - v * u, width: w - 8, height: v * u, rx: 2,
          fill: i === idx ? 'var(--brass)' : 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 1.4
        }));
        svg.appendChild(S('text', {
          x: x0 + i * w + (w - 8) / 2, y: y0 + 16, 'text-anchor': 'middle',
          'font-family': 'IBM Plex Mono, monospace', 'font-size': 11, fill: 'var(--muted)'
        }, String(v)));
      });
      svg.appendChild(S('line', { x1: 20, y1: y0, x2: 360, y2: y0, stroke: 'currentColor', 'stroke-width': 1.6 }));
      var sorted = data.slice().sort(function (a, b) { return a - b; });
      var mean = data.reduce(function (s2, v) { return s2 + v; }, 0) / data.length;
      var median = sorted[(sorted.length - 1) / 2];
      var counts = {}, mode = sorted[0], best = 0;
      sorted.forEach(function (v) { counts[v] = (counts[v] || 0) + 1; if (counts[v] > best) { best = counts[v]; mode = v; } });
      svg.appendChild(S('line', { x1: 20, y1: r1(y0 - mean * u), x2: 360, y2: r1(y0 - mean * u), stroke: 'var(--easy)', 'stroke-width': 1.8, 'stroke-dasharray': '6 4' }));
      svg.appendChild(S('text', { x: 356, y: r1(y0 - mean * u) - 6, 'text-anchor': 'end', 'font-family': 'IBM Plex Mono, monospace', 'font-size': 10.5, fill: 'var(--easy)' }, 'mean'));
      read['values'].textContent = sorted.join(', ');
      read['mean'].textContent = r2(mean);
      read['median'].textContent = median;
      read['mode'].textContent = best > 1 ? mode : 'none';
      read['range'].textContent = sorted[sorted.length - 1] - sorted[0];
    }
    slider(row, 'which value', 1, 7, idx + 1, 1, function (v) { idx = v - 1; draw(); });
    slider(row, 'set it to', 1, 14, data[idx], 1, function (v) { data[idx] = v; draw(); });
    draw();
  };

  /* ---------- mount ---------- */
  /* A prism or cylinder of adjustable base and height, reporting the base area,
     the lateral area, the total surface area and the volume together. The point
     is that changing the height moves S and V by different factors. */
  INT.solidVolume = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Base area times height',
      'Change the base and the height. Watch how the volume and the surface area respond differently.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 240', 460);
    var read = readoutBar(body, ['base area B', 'perimeter P', 'total S', 'volume V']);
    var kind = (opt && opt.kind) || 'prism';   /* 'prism' | 'cylinder' */
    var a = 4, h = 6, n = 6;

    function baseArea() {
      if (kind === 'cylinder') return Math.PI * a * a;
      return n * a * a / (4 * Math.tan(Math.PI / n));
    }
    function basePerim() {
      return kind === 'cylinder' ? 2 * Math.PI * a : n * a;
    }
    function draw() {
      svg.innerHTML = '';
      var B = baseArea(), P = basePerim();
      var cx = 118, ybot = 196, u = 9.5;
      var rx = a * u, ry = rx * 0.34, ht = h * u * 1.6;
      var ytop = ybot - ht;
      if (kind === 'cylinder') {
        svg.appendChild(S('ellipse', {
          cx: cx, cy: ybot, rx: r1(rx), ry: r1(ry),
          fill: 'var(--brand-tint)', 'fill-opacity': 0.5, stroke: 'var(--brand)', 'stroke-width': 1.6
        }));
        svg.appendChild(S('path', {
          d: 'M' + r1(cx - rx) + ' ' + r1(ytop) + ' L' + r1(cx - rx) + ' ' + r1(ybot) +
             ' M' + r1(cx + rx) + ' ' + r1(ytop) + ' L' + r1(cx + rx) + ' ' + r1(ybot),
          fill: 'none', stroke: 'currentColor', 'stroke-width': 2
        }));
        svg.appendChild(S('ellipse', {
          cx: cx, cy: ytop, rx: r1(rx), ry: r1(ry),
          fill: 'var(--brand-tint)', 'fill-opacity': 0.85, stroke: 'var(--brand)', 'stroke-width': 1.8
        }));
      } else {
        var pts = [], i, t;
        for (i = 0; i < n; i++) {
          t = -Math.PI / 2 + i * 2 * Math.PI / n;
          pts.push([cx + rx * Math.cos(t), ybot + ry * Math.sin(t)]);
        }
        var strBot = pts.map(function (q) { return r1(q[0]) + ',' + r1(q[1]); }).join(' ');
        var strTop = pts.map(function (q) { return r1(q[0]) + ',' + r1(q[1] - ht); }).join(' ');
        svg.appendChild(S('polygon', {
          points: strBot, fill: 'var(--brand-tint)', 'fill-opacity': 0.5,
          stroke: 'var(--brand)', 'stroke-width': 1.5
        }));
        for (i = 0; i < n; i++) {
          svg.appendChild(S('line', {
            x1: r1(pts[i][0]), y1: r1(pts[i][1]), x2: r1(pts[i][0]), y2: r1(pts[i][1] - ht),
            stroke: 'currentColor', 'stroke-width': 1.6
          }));
        }
        svg.appendChild(S('polygon', {
          points: strTop, fill: 'var(--brand-tint)', 'fill-opacity': 0.85,
          stroke: 'var(--brand)', 'stroke-width': 1.8
        }));
      }
      /* the height marker */
      svg.appendChild(S('line', {
        x1: cx + rx + 18, y1: ytop, x2: cx + rx + 18, y2: ybot,
        stroke: 'var(--brass)', 'stroke-width': 1.6
      }));
      svg.appendChild(S('text', {
        x: cx + rx + 28, y: (ytop + ybot) / 2, 'font-family': 'Spectral,Georgia,serif',
        'font-size': 14, 'font-style': 'italic', fill: 'var(--brass)'
      }, 'h'));

      /* the two bars, so the different growth is visible */
      var bx = 250, base = 196, bw = 34, top = 40;
      var S_tot = 2 * B + P * h, V = B * h;
      var mx = Math.max(S_tot, V, 1);
      [['S', S_tot, 'var(--brass)'], ['V', V, 'var(--brand)']].forEach(function (c, k) {
        var hh = (base - top) * c[1] / mx;
        svg.appendChild(S('rect', {
          x: bx + k * (bw + 22), y: r1(base - hh), width: bw, height: r1(hh),
          fill: c[2], 'fill-opacity': 0.75
        }));
        svg.appendChild(S('text', {
          x: bx + k * (bw + 22) + bw / 2, y: base + 16, 'font-family': 'IBM Plex Mono,monospace',
          'font-size': 11, fill: 'var(--muted)', 'text-anchor': 'middle'
        }, c[0]));
      });

      read['base area B'].textContent = r1(B);
      read['perimeter P'].textContent = r1(P);
      read['total S'].textContent = r1(S_tot);
      read['volume V'].textContent = r1(V);
    }
    slider(row, kind === 'cylinder' ? 'radius r' : 'base edge a', 1, 8, a, 0.1, function (v) { a = v; draw(); });
    slider(row, 'height h', 1, 10, h, 0.1, function (v) { h = v; draw(); });
    if (kind !== 'cylinder') {
      slider(row, 'sides n', 3, 10, n, 1, function (v) { n = Math.round(v); draw(); });
    }
    draw();
  };

  /* Two similar solids side by side, with the k, k² and k³ factors shown as
     bars. The point learners miss is that the three bars grow at very
     different rates, and the model makes that impossible to miss. */
  INT.scaleSolid = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Lengths, areas and volumes',
      'Change the scale factor k and watch the three quantities grow at different rates.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 230', 460);
    var read = readoutBar(body, ['k', 'length ×', 'area ×k²', 'volume ×k³']);
    var k = 1.5;

    function box(ox, oy, w, h, d, fill, stroke) {
      var o = '';
      var pts = function (a, b) { return a.toFixed(1) + ',' + b.toFixed(1); };
      /* front face */
      o += '<polygon points="' + pts(ox, oy) + ' ' + pts(ox + w, oy) + ' ' +
        pts(ox + w, oy - h) + ' ' + pts(ox, oy - h) + '" fill="' + fill +
        '" fill-opacity="0.75" stroke="' + stroke + '" stroke-width="1.6"/>';
      /* top face */
      o += '<polygon points="' + pts(ox, oy - h) + ' ' + pts(ox + w, oy - h) + ' ' +
        pts(ox + w + d, oy - h - d * 0.6) + ' ' + pts(ox + d, oy - h - d * 0.6) +
        '" fill="' + fill + '" fill-opacity="0.5" stroke="' + stroke + '" stroke-width="1.4"/>';
      /* side face */
      o += '<polygon points="' + pts(ox + w, oy) + ' ' + pts(ox + w + d, oy - d * 0.6) + ' ' +
        pts(ox + w + d, oy - h - d * 0.6) + ' ' + pts(ox + w, oy - h) +
        '" fill="' + fill + '" fill-opacity="0.35" stroke="' + stroke + '" stroke-width="1.4"/>';
      return o;
    }

    function draw() {
      svg.innerHTML = '';
      var base = 34;                       /* the small solid's front width */
      var g = box(24, 168, base, base * 0.8, base * 0.5,
        'var(--faint)', 'var(--muted)');
      var b2 = base * k;
      g += box(96, 168, b2, b2 * 0.8, b2 * 0.5, 'var(--brand-tint)', 'var(--brand)');
      svg.insertAdjacentHTML('beforeend', g);
      svg.appendChild(S('text', {
        x: 24 + base / 2, y: 190, 'font-family': 'IBM Plex Mono,monospace', 'font-size': 10,
        fill: 'var(--muted)', 'text-anchor': 'middle'
      }, 'original'));
      svg.appendChild(S('text', {
        x: 96 + b2 / 2, y: 190, 'font-family': 'IBM Plex Mono,monospace', 'font-size': 10,
        fill: 'var(--muted)', 'text-anchor': 'middle'
      }, 'scaled by k'));

      /* three bars, on a shared logarithmic-free scale capped at the largest */
      var vals = [k, k * k, k * k * k];
      var names = ['k', 'k²', 'k³'];
      var cols = ['var(--easy)', 'var(--brass)', 'var(--brand)'];
      var bx = 236, bot = 176, top = 30, mx = Math.max(vals[2], 1);
      vals.forEach(function (v, i) {
        var hh = (bot - top) * v / mx;
        svg.appendChild(S('rect', {
          x: bx + i * 34, y: r1(bot - hh), width: 24, height: r1(hh),
          fill: cols[i], 'fill-opacity': 0.8
        }));
        svg.appendChild(S('text', {
          x: bx + i * 34 + 12, y: bot + 14, 'font-family': 'IBM Plex Mono,monospace',
          'font-size': 11, fill: 'var(--muted)', 'text-anchor': 'middle'
        }, names[i]));
        svg.appendChild(S('text', {
          x: bx + i * 34 + 12, y: r1(bot - hh) - 6, 'font-family': 'IBM Plex Mono,monospace',
          'font-size': 10, fill: cols[i], 'text-anchor': 'middle'
        }, String(r2(v))));
      });

      read['k'].textContent = r2(k);
      read['length ×'].textContent = r2(k);
      read['area ×k²'].textContent = r2(k * k);
      read['volume ×k³'].textContent = r2(k * k * k);
    }
    slider(row, 'scale factor k', 0.5, 3, k, 0.05, function (v) { k = v; draw(); });
    draw();
  };

  INT.mount = function (host, spec) {
    var fn = INT[spec.type];
    if (!fn) { host.innerHTML = '<p class="small">Unknown model: ' + spec.type + '</p>'; return; }
    try { fn(host, spec); }
    catch (e) { host.innerHTML = '<p class="small">This model could not start: ' + e.message + '</p>'; }
  };


  /* ============ 23. graph transformations ============
     y = a·f(x − b) + c on top of y = f(x), so the class can see which knob
     moves the curve and which reshapes it. */
  INT.graphTransform = function (host, opt) {
    opt = opt || {};
    var body = frame(host, opt.title || 'Transforming a graph',
      'Move a, b and c. The grey curve is y = f(x); the coloured one is the transform.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 280', 460);
    var read = readoutBar(body, ['a', 'b', 'c', 'equation']);
    var a = 1, b = 0, c = 0, u = 26, cx = 180, cy = 168;
    var base = opt.f || function (x) { return x * x; };
    function draw() {
      svg.innerHTML = '';
      var i;
      for (i = -6; i <= 6; i++) {
        svg.appendChild(S('line', { x1: cx + i * u, y1: 8, x2: cx + i * u, y2: 272, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
        svg.appendChild(S('line', { x1: 8, y1: cy + i * u, x2: 352, y2: cy + i * u, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      }
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 272, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      function path(f, col, wid) {
        var d = '', started = false;
        for (var x = -6.6; x <= 6.6; x += 0.05) {
          var y = f(x);
          if (!isFinite(y) || Math.abs(y) > 9) { started = false; continue; }
          d += (started ? 'L' : 'M') + (cx + x * u).toFixed(1) + ' ' + (cy - y * u).toFixed(1) + ' ';
          started = true;
        }
        svg.appendChild(S('path', { d: d, fill: 'none', stroke: col, 'stroke-width': wid }));
      }
      path(base, 'var(--faint)', 2);
      path(function (x) { return a * base(x - b) + c; }, 'var(--brand)', 2.8);
      read['a'].textContent = a;
      read['b'].textContent = b;
      read['c'].textContent = c;
      read['equation'].textContent = 'y = ' + (a === 1 ? '' : a + '·') + 'f(x' +
        (b === 0 ? '' : (b > 0 ? ' − ' + b : ' + ' + (-b))) + ')' +
        (c === 0 ? '' : (c > 0 ? ' + ' + c : ' − ' + (-c)));
    }
    slider(row, 'a  stretch', -2, 3, 1, 0.5, function (v) { a = v; draw(); });
    slider(row, 'b  across', -4, 4, 0, 0.5, function (v) { b = v; draw(); });
    slider(row, 'c  up', -4, 4, 0, 0.5, function (v) { c = v; draw(); });
    draw();
  };

  /* ============ 24. the derivative as a limit ============ */
  INT.derivative = function (host, opt) {
    opt = opt || {};
    var body = frame(host, opt.title || 'The secant becomes the tangent',
      'Slide h towards 0 and watch the gradient of PQ settle on the derivative.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 280', 460);
    var read = readoutBar(body, ['x', 'h', 'Δy / Δx', "f ′(x) exactly"]);
    var f = opt.f || function (x) { return 0.4 * x * x; };
    var df = opt.df || function (x) { return 0.8 * x; };
    var x0 = 2, h = 2, u = 34, cx = 46, cy = 244;
    function draw() {
      svg.innerHTML = '';
      var i;
      for (i = 0; i <= 9; i++) svg.appendChild(S('line', { x1: cx + i * u, y1: 8, x2: cx + i * u, y2: 268, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      for (i = 0; i <= 7; i++) svg.appendChild(S('line', { x1: 8, y1: cy - i * u, x2: 352, y2: cy - i * u, stroke: 'var(--rule-soft)', 'stroke-width': 1 }));
      svg.appendChild(S('line', { x1: 8, y1: cy, x2: 352, y2: cy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: cx, y1: 8, x2: cx, y2: 268, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      var d = '', started = false;
      for (var x = -0.3; x <= 8.8; x += 0.04) {
        var y = f(x);
        if (y * u > cy - 6) { started = false; continue; }
        d += (started ? 'L' : 'M') + (cx + x * u).toFixed(1) + ' ' + (cy - y * u).toFixed(1) + ' ';
        started = true;
      }
      svg.appendChild(S('path', { d: d, fill: 'none', stroke: 'var(--brand)', 'stroke-width': 2.6 }));
      var P = [cx + x0 * u, cy - f(x0) * u], x1 = x0 + h, Q = [cx + x1 * u, cy - f(x1) * u];
      var m = h === 0 ? df(x0) : (f(x1) - f(x0)) / h;
      /* the secant, extended right across the frame */
      var xa = -0.3, xb = 8.8;
      svg.appendChild(S('line', {
        x1: cx + xa * u, y1: cy - (f(x0) + m * (xa - x0)) * u,
        x2: cx + xb * u, y2: cy - (f(x0) + m * (xb - x0)) * u,
        stroke: 'var(--brass)', 'stroke-width': 2.4
      }));
      if (h !== 0) {
        svg.appendChild(S('line', { x1: P[0], y1: P[1], x2: Q[0], y2: P[1], stroke: 'var(--faint)', 'stroke-width': 1.8, 'stroke-dasharray': '5 4' }));
        svg.appendChild(S('line', { x1: Q[0], y1: P[1], x2: Q[0], y2: Q[1], stroke: 'var(--faint)', 'stroke-width': 1.8, 'stroke-dasharray': '5 4' }));
        svg.appendChild(S('circle', { cx: Q[0], cy: Q[1], r: 5, fill: 'var(--brass)' }));
      }
      svg.appendChild(S('circle', { cx: P[0], cy: P[1], r: 5.5, fill: 'var(--brand)' }));
      read['x'].textContent = r2(x0);
      read['h'].textContent = r2(h);
      read['Δy / Δx'].textContent = r2(m);
      read["f ′(x) exactly"].textContent = r2(df(x0));
    }
    slider(row, 'x', 0.5, 5, x0, 0.5, function (v) { x0 = v; draw(); });
    slider(row, 'h', 0, 3, h, 0.05, function (v) { h = v; draw(); });
    draw();
  };

  /* ============ 25. solving a triangle with the sine and cosine rules ==== */
  INT.solveTriangle = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'The sine and cosine rules',
      'Change two sides and the angle between them; every other part follows.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 250', 460);
    var read = readoutBar(body, ['b', 'c', 'A', 'a', 'B', 'C', 'area']);
    var b = 7, c = 9, A = 55;
    function draw() {
      svg.innerHTML = '';
      var rad = A * Math.PI / 180;
      var a = Math.sqrt(b * b + c * c - 2 * b * c * Math.cos(rad));
      var Bang = Math.asin(Math.min(1, b * Math.sin(rad) / a)) * 180 / Math.PI;
      var Cang = 180 - A - Bang;
      var k = 200 / Math.max(a, b, c);
      var Ap = [70, 200], Bp = [70 + c * k, 200];
      var Cp = [70 + b * k * Math.cos(rad), 200 - b * k * Math.sin(rad)];
      svg.appendChild(S('polygon', {
        points: [Ap, Bp, Cp].map(function (p) { return r1(p[0]) + ',' + r1(p[1]); }).join(' '),
        fill: 'var(--brand-tint)', stroke: 'currentColor', 'stroke-width': 2.2, 'stroke-linejoin': 'round'
      }));
      function lab(p, t, dx, dy, col) {
        svg.appendChild(S('text', {
          x: p[0] + dx, y: p[1] + dy, 'font-family': 'Spectral,Georgia,serif', 'font-size': 14,
          'font-style': 'italic', fill: col || 'currentColor', 'text-anchor': 'middle'
        }, t));
      }
      lab(Ap, 'A', -14, 6); lab(Bp, 'B', 14, 6); lab(Cp, 'C', 0, -12);
      lab([(Ap[0] + Bp[0]) / 2, Ap[1]], 'c', 0, 18, 'var(--muted)');
      lab([(Ap[0] + Cp[0]) / 2, (Ap[1] + Cp[1]) / 2], 'b', -14, 0, 'var(--muted)');
      lab([(Bp[0] + Cp[0]) / 2, (Bp[1] + Cp[1]) / 2], 'a', 14, 0, 'var(--brass)');
      read['b'].textContent = b; read['c'].textContent = c; read['A'].textContent = A + '°';
      read['a'].textContent = r2(a);
      read['B'].textContent = r1(Bang) + '°';
      read['C'].textContent = r1(Cang) + '°';
      read['area'].textContent = r2(0.5 * b * c * Math.sin(rad));
    }
    slider(row, 'b', 3, 12, b, 0.5, function (v) { b = v; draw(); });
    slider(row, 'c', 3, 12, c, 0.5, function (v) { c = v; draw(); });
    slider(row, 'A°', 15, 150, A, 5, function (v) { A = v; draw(); });
    draw();
  };

  /* ============ 26. a point and a vector in space ============ */
  INT.space3d = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'A point in space',
      'Move x, y and z. The box shows why the distance formula is Pythagoras twice.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 260', 460);
    var read = readoutBar(body, ['x', 'y', 'z', 'OM', 'base diagonal']);
    var X = 3, Y = 2, Z = 2, s = 30, ox = 92, oy = 214, kx = 0.5, ky = 0.36;
    function P(x, y, z) { return [ox + (x + kx * z) * s, oy - (y + ky * z) * s]; }
    function ln(a, b, col, w, dash) {
      var o = { x1: r1(a[0]), y1: r1(a[1]), x2: r1(b[0]), y2: r1(b[1]), stroke: col, 'stroke-width': w };
      if (dash) o['stroke-dasharray'] = dash;
      svg.appendChild(S('line', o));
    }
    function draw() {
      svg.innerHTML = '';
      var O = P(0, 0, 0);
      ln(O, P(4.4, 0, 0), 'var(--faint)', 1.6);
      ln(O, P(0, 3.4, 0), 'var(--faint)', 1.6);
      ln(O, P(0, 0, 3.6), 'var(--faint)', 1.6);
      var F = P(X, 0, Z), M = P(X, Y, Z);
      ln(O, P(X, 0, 0), 'var(--brass)', 2);
      ln(P(X, 0, 0), F, 'var(--brass)', 2);
      ln(F, M, 'var(--brass)', 2);
      ln(O, F, 'var(--faint)', 1.8, '5 4');
      ln(O, M, 'var(--brand)', 3);
      svg.appendChild(S('circle', { cx: r1(M[0]), cy: r1(M[1]), r: 5.5, fill: 'var(--brand)' }));
      svg.appendChild(S('circle', { cx: r1(F[0]), cy: r1(F[1]), r: 3.4, fill: 'var(--faint)' }));
      [[P(4.4, 0, 0), 'x'], [P(0, 3.4, 0), 'z'], [P(0, 0, 3.6), 'y']].forEach(function (t) {
        svg.appendChild(S('text', {
          x: t[0][0] + 10, y: t[0][1] + 4, 'font-family': 'IBM Plex Mono,monospace',
          'font-size': 11, fill: 'var(--muted)'
        }, t[1]));
      });
      read['x'].textContent = X; read['y'].textContent = Z; read['z'].textContent = Y;
      read['OM'].textContent = r2(Math.sqrt(X * X + Y * Y + Z * Z));
      read['base diagonal'].textContent = r2(Math.sqrt(X * X + Z * Z));
    }
    slider(row, 'x', 0, 4, X, 0.5, function (v) { X = v; draw(); });
    slider(row, 'y', 0, 3.5, Z, 0.5, function (v) { Z = v; draw(); });
    slider(row, 'z', 0, 3, Y, 0.5, function (v) { Y = v; draw(); });
    draw();
  };

  /* ============ 27. optimisation: the open box ============ */
  INT.optimise = function (host, opt) {
    var body = frame(host, (opt && opt.title) || 'Where is the volume greatest?',
      'Slide the corner square x. The graph plots V against x; the peak is the answer.');
    var row = ctrlRow(body);
    var svg = stage(body, '0 0 360 250', 460);
    var read = readoutBar(body, ['x', 'V(x)', 'greatest V', 'at x =']);
    var A = 20, B = 16, x = 2;
    function V(t) { return t * (A - 2 * t) * (B - 2 * t); }
    function draw() {
      svg.innerHTML = '';
      var xmax = Math.min(A, B) / 2, best = 0, bx = 0, t;
      for (t = 0.01; t < xmax; t += 0.005) if (V(t) > best) { best = V(t); bx = t; }
      var ox = 44, oy = 214, w = 292, h = 178;
      svg.appendChild(S('line', { x1: ox, y1: oy, x2: ox + w, y2: oy, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      svg.appendChild(S('line', { x1: ox, y1: oy, x2: ox, y2: oy - h - 10, stroke: 'var(--faint)', 'stroke-width': 1.6 }));
      var sx = w / xmax, sy = h / best;
      var d = '';
      for (t = 0; t <= xmax; t += 0.02) {
        d += (t === 0 ? 'M' : 'L') + (ox + t * sx).toFixed(1) + ' ' + (oy - V(t) * sy).toFixed(1) + ' ';
      }
      svg.appendChild(S('path', { d: d, fill: 'none', stroke: 'var(--brand)', 'stroke-width': 2.6 }));
      svg.appendChild(S('line', {
        x1: ox + bx * sx, y1: oy, x2: ox + bx * sx, y2: oy - best * sy,
        stroke: 'var(--brass)', 'stroke-width': 1.6, 'stroke-dasharray': '5 4'
      }));
      svg.appendChild(S('circle', { cx: r1(ox + bx * sx), cy: r1(oy - best * sy), r: 4.5, fill: 'var(--brass)' }));
      svg.appendChild(S('circle', { cx: r1(ox + x * sx), cy: r1(oy - V(x) * sy), r: 5.5, fill: 'var(--brand)' }));
      svg.appendChild(S('text', {
        x: ox + w - 4, y: oy + 18, 'font-family': 'IBM Plex Mono,monospace', 'font-size': 11,
        fill: 'var(--muted)', 'text-anchor': 'end'
      }, 'x'));
      svg.appendChild(S('text', {
        x: ox - 8, y: oy - h - 2, 'font-family': 'IBM Plex Mono,monospace', 'font-size': 11,
        fill: 'var(--muted)', 'text-anchor': 'end'
      }, 'V'));
      read['x'].textContent = r2(x);
      read['V(x)'].textContent = r1(V(x));
      read['greatest V'].textContent = r1(best);
      read['at x ='].textContent = r2(bx);
    }
    slider(row, 'x', 0.5, 7.5, x, 0.1, function (v) { x = v; draw(); });
    draw();
  };

  w.INT = INT;
})(window, document);

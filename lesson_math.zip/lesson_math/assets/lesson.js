/* Renders one topic page from a TOPIC object. */
(function (w, d) {
  'use strict';
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  function I18N() { return w.AKM_I18N; }
  function t(key, vars) { var i = I18N(); return i ? i.t(key, vars) : key; }
  function lang() { var i = I18N(); return i ? i.lang() : 'en'; }
  /* Field-level fallback: a translated topic overrides just the fields it
     has; anything missing (including every topic not yet translated) reads
     straight from the English object, so a page never breaks or goes blank
     when the reader switches language. */
  function L(T, field) {
    var i = I18N();
    if (i) return i.pick(T, field);
    return T[field];
  }

  // {{fig:name}} -> inline SVG figure
  function figs(html) {
    return String(html).replace(/\{\{fig:([a-zA-Z0-9_]+)(?::([^}]*))?\}\}/g, function (_, name, cap) {
      var fn = w.FIG && w.FIG[name];
      if (!fn) return '<p class="small">[missing figure: ' + name + ']</p>';
      return '<figure class="fig">' + fn() +
        (cap ? '<figcaption>' + cap + '</figcaption>' : '') + '</figure>';
    });
  }

  function levelBlock(title, cls, chip, items) {
    var id = 'pl' + Math.random().toString(36).slice(2, 7);
    return '<div class="plevel ' + cls + '">' +
      '<div class="ph"><h3>' + title + '</h3><span class="chip ' + chip + '">' + items.length + ' ' + t('problems') + '</span>' +
      '<button class="btn sm no-print pc-btn" type="button" data-t="' + id + '">' + t('showAnswers') + '</button></div>' +
      '<ol class="probs" id="' + id + '">' +
      items.map(function (it) {
        return '<li><div><div class="pq">' + it[0] + '</div>' +
          '<div class="pa"><span class="al">' + t('answer') + '</span>' + it[1] + '</div></div><span></span></li>';
      }).join('') + '</ol></div>';
  }

  /* translate="no" was once needed so a machine translator would not rewrite
     these three columns; the site no longer runs one, but the attribute is
     harmless and a reader's own browser translator (if any) should still
     leave the vocabulary table alone. */
  function termsTable(list) {
    return '<div class="tablewrap terms notranslate" translate="no"><table>' +
      '<thead><tr><th>English</th><th>O‘zbekcha</th><th>Русский</th></tr></thead><tbody>' +
      list.map(function (t) {
        return '<tr><td>' + t[0] + '</td><td class="uz" lang="uz">' + t[1] +
          '</td><td class="ru" lang="ru">' + t[2] + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  var LAST = null;   /* { T: topic, INDEX: index } of the last render, so a
                         language change can redraw without re-fetching */

  function render(T, INDEX) {
    LAST = { T: T, INDEX: INDEX };
    var l = lang();
    var title = L(T, 'title') || T.title;
    d.title = title + ' · ' + t('grade') + ' ' + T.grade + ' · Anvarbek Khaydarov';
    var streamName = T.stream === 'alg' ? t('algebra') : t('geometry');
    var translated = I18N() && I18N().hasTranslation(T, l);

    /* title of any topic in INDEX, translated if that topic has been */
    function xTitle(x) { return (x.topic && L(x.topic, 'title')) || x.title; }

    /* ---- header ---- */
    var i0 = INDEX.findIndex(function (x) { return x.id === T.id; });
    var prev0 = INDEX[i0 - 1], next0 = INDEX[i0 + 1];
    var opts = INDEX.map(function (x) {
      return '<option value="' + x.id + '"' + (x.id === T.id ? ' selected' : '') + '>' +
        (x.group ? x.group + ' · ' : '') + xTitle(x) + '</option>';
    }).join('');
    var arrow = function (dir) {
      return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="' +
        (dir < 0 ? 'M15 6l-6 6 6 6' : 'M9 6l6 6-6 6') + '"/></svg>';
    };

    var subtitle = L(T, 'subtitle');
    var objectives = L(T, 'objectives') || T.objectives;

    var head = d.getElementById('lhead');
    head.innerHTML = '<div class="inner">' +
      '<div class="lnav no-print">' +
      '<a class="backbtn" href="grade.html?g=' + T.grade + '" id="backbtn">' +
      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M19 12H5M11 5l-7 7 7 7"/></svg>' + t('back', { g: T.grade }) + '</a>' +
      '<span class="jump"><select id="jumpsel" aria-label="Jump to another topic">' + opts + '</select></span>' +
      '<span class="stepper">' +
      '<a class="stepbtn" href="' + (prev0 ? 'lesson.html?t=' + prev0.id : '#') + '"' +
      (prev0 ? ' title="' + xTitle(prev0) + '"' : ' aria-disabled="true"') + ' aria-label="Previous topic">' + arrow(-1) + '</a>' +
      '<a class="stepbtn" href="' + (next0 ? 'lesson.html?t=' + next0.id : '#') + '"' +
      (next0 ? ' title="' + xTitle(next0) + '"' : ' aria-disabled="true"') + ' aria-label="Next topic">' + arrow(1) + '</a>' +
      '</span></div>' +
      '<p class="crumb"><a href="index.html">' + t('home') + '</a> / <a href="grade.html?g=' + T.grade + '">' + t('grade') + ' ' +
      T.grade + '</a> / ' + streamName + ' / ' + t('quarter') + ' ' + T.quarter + '</p>' +
      '<h1>' + title + '</h1>' +
      (subtitle ? '<p class="lede" style="margin-top:12px">' + subtitle + '</p>' : '') +
      '<div class="ltags">' +
      '<span class="chip solid">' + t('lesson', { r: T.lessons }) + '</span>' +
      '<span class="chip">' + T.hours + ' ' + t('perHour') + '</span>' +
      (T.uz ? '<span class="chip c-uz">' + T.uz + '</span>' : '') +
      (T.cam ? '<span class="chip c-cam">' + T.cam + '</span>' : '') +
      (l !== 'en' && !translated ? '<span class="chip c-untranslated">' +
        (l === 'uz' ? 'Hozircha ingliz tilida' : 'Пока на английском') + '</span>' : '') +
      '</div></div>';

    /* ---- sidebar ---- */
    var side = d.getElementById('lside');
    var clock = (L(T, 'timing') || T.timing || [[5, 'Warm-up'], [12, 'Explanation'], [8, 'Interactive'], [13, 'Practice'], [2, 'Homework']]);
    var cols = ['var(--faint)', 'var(--brand)', 'var(--brass)', 'var(--easy)', 'var(--hard)'];
    side.innerHTML =
      '<div class="sbox"><h5>' + t('clock') + '</h5>' +
      '<div class="clock" style="margin:0 0 12px">' + clock.map(function (c, i) {
        return '<div style="flex:' + c[0] + ';background:' + cols[i % cols.length] + '" title="' +
          c[1] + '">' + c[0] + "'</div>";
      }).join('') + '</div>' +
      clock.map(function (c, i) {
        return '<div class="kv"><b>' + c[1] + '</b><span>' + c[0] + ' min</span></div>';
      }).join('') + '</div>' +
      '<div class="sbox"><h5>' + t('objectives') + '</h5><ul>' +
      objectives.map(function (o) { return '<li>' + o + '</li>'; }).join('') + '</ul></div>' +
      '<div class="sbox"><h5>' + t('textbook') + '</h5>' +
      (T.uz ? '<div class="kv"><b>' + t('national') + '</b><span>' + T.uzPage + '</span></div>' : '') +
      (T.camPage ? '<div class="kv"><b>' + t('cambridge') + '</b><span>' + T.camPage + '</span></div>' : '') +
      (T.wb ? '<div class="kv"><b>' + t('workbook') + '</b><span>' + T.wb + '</span></div>' : '') +
      '</div>' +
      '<div class="sbox no-print"><h5>' + t('onThisPage') + '</h5><nav class="tocnav">' +
      '<a href="#explain">' + t('secExplain') + '</a><a href="#examples">' + t('secExamples') + '</a>' +
      '<a href="#model">' + t('secModel') + '</a><a href="#terms">' + t('secTerms') + '</a>' +
      '<a href="#check">' + t('secCheck') + '</a>' +
      '<a href="#practice">' + t('secPractice') + '</a><a href="#homework">' + t('secHomework') + '</a></nav></div>' +
      '<div class="sbox no-print"><button class="btn sm" type="button" onclick="window.print()">' + t('print') + '</button></div>';

    /* ---- main ---- */
    var main = d.getElementById('lmain');
    var html = '';
    var sections = L(T, 'sections') || T.sections;
    var examples = L(T, 'examples') || T.examples;
    var quiz = L(T, 'quiz') || T.quiz;
    var practice = L(T, 'practice') || T.practice;
    var homework = L(T, 'homework') || T.homework;
    var hwTitle = L(T, 'hwTitle');
    var hwNote = L(T, 'hwNote');
    var modelNote = L(T, 'modelNote');
    var interactiveText = (I18N() && I18N().lang() !== 'en' && T.i18n && T.i18n[I18N().lang()] && T.i18n[I18N().lang()].interactive) || null;

    html += '<section class="lsec" id="explain"><h2><span class="sn">01</span>' + t('secExplain') + '</h2>';
    sections.forEach(function (s) {
      if (s.h) html += '<h3 style="margin:28px 0 12px">' + s.h + '</h3>';
      html += '<div class="prose">' + figs(s.html) + '</div>';
    });
    html += '</section>';

    if (examples && examples.length) {
      html += '<section class="lsec" id="examples"><h2><span class="sn">02</span>' + t('secExamples') + '</h2>';
      examples.forEach(function (ex, i) {
        html += '<div class="example"><div class="eh"><span class="et">' + t('example', { n: i + 1 }) + '</span>' +
          '<span class="eq2">' + ex.q + '</span></div><div class="eb"><ol class="steps">' +
          ex.steps.map(function (s) {
            return '<li><div>' + s[0] + (s[1] ? '<span class="why">' + s[1] + '</span>' : '') + '</div></li>';
          }).join('') + '</ol>' +
          (ex.ans ? '<div class="keybox" style="margin-bottom:0"><div class="klabel">' + t('answer') + '</div>' + ex.ans + '</div>' : '') +
          '</div></div>';
      });
      html += '</section>';
    }

    html += '<section class="lsec" id="model"><h2><span class="sn">03</span>' + t('secModel') + '</h2>' +
      '<p class="small" style="margin-bottom:4px">' + (modelNote || t('modelDefault')) + '</p>' +
      '<div id="ilab"></div></section>';

    if (T.terms && T.terms.length) {
      html += '<section class="lsec" id="terms"><h2><span class="sn">04</span>' + t('secTerms') + '</h2>' +
        '<p class="small">' + t('termsNote') + '</p>' +
        termsTable(T.terms) +
        '<p class="termnote">' + t('termsNote2') + '</p></section>';
    }
    if (quiz && quiz.length) {
      html += '<section class="lsec" id="check"><h2><span class="sn">05</span>' + t('secCheck') + '</h2>' +
        '<div id="quizlab"></div></section>';
    }

    html += '<section class="lsec" id="practice"><h2><span class="sn">06</span>' + t('secPracticeHead') + '</h2>' +
      '<p class="small">' + t('practiceNote') + '</p>' +
      levelBlock(t('easy'), 'lv-easy', 'c-easy', practice.easy) +
      levelBlock(t('medium'), 'lv-med', 'c-med', practice.med) +
      levelBlock(t('hard'), 'lv-hard', 'c-hard', practice.hard) +
      '</section>';

    html += '<section class="lsec" id="homework"><h2><span class="sn">07</span>' + t('secHomework') + '</h2>' +
      '<div class="hw"><h3>' + (hwTitle || t('homeworkDefault')) + '</h3>' +
      '<p class="hwt">' + (hwNote || '') + '</p><ol>' +
      homework.map(function (h) { return '<li>' + h + '</li>'; }).join('') + '</ol></div></section>';

    /* pager */
    var prev = prev0, next = next0;
    html += '<div class="pager no-print">' +
      (prev ? '<a href="lesson.html?t=' + prev.id + '"><span class="pl">' + t('prev') + '</span><span class="pt">' + xTitle(prev) + '</span></a>' : '<span></span>') +
      (next ? '<a class="nx" href="lesson.html?t=' + next.id + '"><span class="pl">' + t('next') + '</span><span class="pt">' + xTitle(next) + '</span></a>' : '<span></span>') +
      '</div>' +
      '<div class="mobilepager no-print">' +
      '<a href="' + (prev ? 'lesson.html?t=' + prev.id : '#') + '"' + (prev ? '' : ' aria-disabled="true"') + '>' + t('prev') + '</a>' +
      '<a href="grade.html?g=' + T.grade + '">' + t('allTopics') + '</a>' +
      '<a href="' + (next ? 'lesson.html?t=' + next.id : '#') + '"' + (next ? '' : ' aria-disabled="true"') + '>' + t('next') + '</a>' +
      '</div>';

    main.innerHTML = html;

    /* behaviour */
    [].forEach.call(d.querySelectorAll('.pc-btn'), function (b) {
      b.addEventListener('click', function () {
        var tgt = d.getElementById(b.getAttribute('data-t'));
        var on = tgt.classList.toggle('show');
        b.textContent = on ? t('hideAnswers') : t('showAnswers');
      });
    });
    var jump = d.getElementById('jumpsel');
    if (jump) jump.addEventListener('change', function () {
      w.location.href = (w.AKM_lessonHref || function (id) { return 'lesson.html?t=' + id; })(jump.value);
    });
    if (T.interactive) {
      var intOpt = T.interactive;
      if (interactiveText) {
        intOpt = {};
        for (var k in T.interactive) if (Object.prototype.hasOwnProperty.call(T.interactive, k)) intOpt[k] = T.interactive[k];
        for (var k2 in interactiveText) if (Object.prototype.hasOwnProperty.call(interactiveText, k2)) {
          if (k2 === 'items' && T.interactive.items) {
            /* element-wise merge, so a translated item that omits a math-only
               field (like `start`, identical in every language) still gets it
               from the English original rather than coming up blank. */
            intOpt.items = T.interactive.items.map(function (orig, i) {
              var tr = interactiveText.items[i];
              if (!tr) return orig;
              var merged = {};
              for (var ok in orig) if (Object.prototype.hasOwnProperty.call(orig, ok)) merged[ok] = orig[ok];
              for (var tk in tr) if (Object.prototype.hasOwnProperty.call(tr, tk)) merged[tk] = tr[tk];
              return merged;
            });
          } else {
            intOpt[k2] = interactiveText[k2];
          }
        }
      }
      w.INT.mount(d.getElementById('ilab'), intOpt);
    }
    if (quiz && quiz.length) w.INT.mount(d.getElementById('quizlab'), { type: 'quiz', items: quiz });

    /* toc highlight */
    var secs = [].slice.call(d.querySelectorAll('.lsec'));
    var links = [].slice.call(d.querySelectorAll('.tocnav a'));
    if ('IntersectionObserver' in w) {
      var io = new IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (!e.isIntersecting) return;
          links.forEach(function (l) {
            l.classList.toggle('on', l.getAttribute('href') === '#' + e.target.id);
          });
        });
      }, { rootMargin: '-90px 0px -70% 0px' });
      secs.forEach(function (s) { io.observe(s); });
    }

    /* the page was empty when the motion layer first ran */
    if (w.AKM_MOTION) w.AKM_MOTION.refresh();
  }

  w.renderTopic = function (T, INDEX) { render(T, INDEX); };

  w.addEventListener('akm:langchange', function () {
    if (LAST) render(LAST.T, LAST.INDEX);
  });
})(window, document);

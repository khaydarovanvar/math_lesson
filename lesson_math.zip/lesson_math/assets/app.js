/* Shared chrome: logo, header, footer, theme. No dependencies. */
(function (w) {
  'use strict';

  /* The mark: a pair of compasses part way through its sweep. The ring is left
     open at the lower right, where the nib still rests — geometry caught
     mid-construction. The arc carries a class so the preloader can draw it. */
  var ARC_D = 'M40.03 56.73 A26 26 0 1 1 54.96 44.21';
  var A_D = 'M32 15 L20 47 M32 15 L44 47 M24.2 36 H39.8';
  var LOGO = '<svg viewBox="0 0 64 64" role="img" aria-label="Anvarbek Khaydarov Mathematics">' +
    '<path class="lg-arc" d="' + ARC_D + '" fill="none" stroke="var(--brass)" ' +
      'stroke-width="2.6" stroke-linecap="round"/>' +
    '<circle class="lg-nib" cx="54.96" cy="44.21" r="2.9" fill="var(--brass)"/>' +
    '<path class="lg-a" d="' + A_D + '" fill="none" stroke="currentColor" ' +
      'stroke-width="3.7" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';

  // path prefix so the site works from any folder depth
  var ROOT = (function () {
    var d = document.currentScript && document.currentScript.getAttribute('data-root');
    return d || './';
  })();

  function brandmark(sub) {
    return '<a class="brandmark" href="' + ROOT + 'index.html">' + LOGO +
      '<span><span class="bn">Anvarbek Khaydarov</span>' +
      '<span class="bs">' + (sub || 'Mathematics') + '</span></span></a>';
  }

  var GRADES_MENU = [5, 6, 7, 8, 9, 10, 11];

  function I18N() { return w.AKM_I18N; }
  function t(key, vars) { var i = I18N(); return i ? i.t(key, vars) : key; }

  function NAV() {
    return [
      ['index.html', t('navHome')],
      ['grades.html', t('navGrades'), 'grades'],
      ['plans.html', t('navPlans')],
      ['terminology.html', t('navTerms')],
      ['about.html', t('navAbout')]
    ];
  }

  /* What the grades drop-down says under each year. Keyed by grade; anything
     not listed is still to be written. */
  function menuNote(g) {
    var n = (w.TOPIC_COUNTS || {})[g];
    return n ? t('menuAllLessons', { n: n }) : t('menuComing');
  }

  var LANG_NAMES = { en: 'EN', uz: 'UZ', ru: 'RU' };

  function langSwitcher() {
    var i = I18N();
    var cur = i ? i.lang() : 'en';
    var opts = (i ? i.SUPPORTED : ['en', 'uz', 'ru']).map(function (l) {
      return '<option value="' + l + '"' + (l === cur ? ' selected' : '') + '>' + LANG_NAMES[l] + '</option>';
    }).join('');
    return '<div class="langpick" id="langpick">' +
      '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" ' +
      'stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/>' +
      '<path d="M3 12h18M12 3a15 15 0 0 1 0 18a15 15 0 0 1 0-18"/></svg>' +
      '<select id="langsel" aria-label="' + t('langLabel') + '">' + opts + '</select></div>';
  }

  function header(active) {
    var links = NAV().map(function (n) {
      var on = n[0].split('?')[0] === active || n[0] === active ? ' class="on"' : '';
      if (n[2] !== 'grades') return '<a href="' + ROOT + n[0] + '"' + on + '>' + n[1] + '</a>';
      /* Grades gets a drop-down, so any year is one click from anywhere. */
      return '<span class="hasmenu"><a href="' + ROOT + n[0] + '"' + on + '>' + n[1] +
        '<svg class="caret" width="10" height="10" viewBox="0 0 24 24" fill="none" ' +
        'stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true">' +
        '<path d="M6 9l6 6 6-6"/></svg></a>' +
        '<span class="submenu">' + GRADES_MENU.map(function (g) {
          return '<a href="' + ROOT + 'grade.html?g=' + g + '">' + t('grade') + ' ' + g +
            '<em>' + menuNote(g) + '</em></a>';
        }).join('') + '</span></span>';
    }).join('');
    return '<header class="site-head" id="sitehead"><div class="bar">' + brandmark() +
      '<div class="solidstrip" id="solidstrip" aria-hidden="true"></div>' +
      '<div class="navwrap"><nav class="nav" id="navlinks">' + links + '</nav>' +
      '<div class="findwrap"><button class="findbtn" id="findbtn" type="button" ' +
      'aria-label="' + t('searchTitle') + '" title="' + t('searchTitle') + '">' +
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/>' +
      '<path d="M20 20l-4.3-4.3"/></svg></button></div>' +
      langSwitcher() +
      '<button class="themebtn" id="themebtn" type="button" aria-label="' + t('themeTitle') + '" title="' + t('themeTitle') + '">' +
      '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">' +
      '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg></button>' +
      '<button class="menubtn" id="menubtn" type="button" aria-label="' + t('menuTitle') + '" aria-expanded="false">' +
      '<span></span><span></span><span></span></button></div></div>' +
      /* A slim strip of moving text under the bar. It folds away as soon as the
         page scrolls, so it greets a reader without following them down. */
      '<div class="headtick" aria-hidden="true"><div class="marquee-track"><span>' +
      SLOGAN + '</span></div></div>' +
      '<i class="readbar" id="readbar" aria-hidden="true"></i></header>';
  }

  function langBehaviour() {
    var sel = document.getElementById('langsel');
    if (sel) sel.addEventListener('change', function () {
      if (w.AKM_I18N) w.AKM_I18N.setLang(sel.value);
    });
  }

  /* Registered once per page load. Redraws the chrome (header + footer) in
     the new language; a page-specific listener (lesson.js, grade.html)
     redraws its own body the same way. */
  var LANGCHANGE_BOUND = false;
  function bindLangchangeOnce() {
    if (LANGCHANGE_BOUND) return;
    LANGCHANGE_BOUND = true;
    w.addEventListener('akm:langchange', function () {
      var h = document.getElementById('sitehead');
      var active = h ? h.getAttribute('data-active') || '' : '';
      if (h) h.outerHTML = header(active);
      var newHead = document.getElementById('sitehead');
      if (newHead) newHead.setAttribute('data-active', active);
      var f = document.getElementById('sitefoot');
      if (f) f.outerHTML = footer();
      navBehaviour(); searchBehaviour(); langBehaviour(); theme(); mountSolids();
    });
  }

  function navBehaviour() {
    var mb = document.getElementById('menubtn'), head = document.getElementById('sitehead');
    if (mb) mb.addEventListener('click', function () {
      var open = head.classList.toggle('open');
      mb.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    if (head) {
      var onScroll = function () { head.classList.toggle('scrolled', w.scrollY > 8); };
      w.addEventListener('scroll', onScroll, { passive: true }); onScroll();
      head.addEventListener('click', function (e) {
        if (e.target.tagName === 'A') head.classList.remove('open');
      });
    }
  }

  /* ---------- topic search ----------
     Ninety-five topics is more than a menu can hold. The search reads whatever
     lesson data the page has loaded and matches on title, subtitle, the
     terminology in all three languages, and the textbook reference — so
     "vatar", "хорда" and "chord" all find the same lesson. */

  function searchIndex() {
    var all = allTopics();
    return all.map(function (t) {
      var terms = (t.terms || []).map(function (r) { return r.join(' '); }).join(' ');
      return {
        id: t.id,
        title: t.title,
        lcTitle: t.title.toLowerCase(),
        lcSub: (t.subtitle || '').toLowerCase(),
        meta: 'Grade ' + t.grade + ' · ' + (t.stream === 'alg' ? 'Algebra' : 'Geometry') +
          ' · Quarter ' + t.quarter + ' · L' + t.lessons,
        hay: (t.title + ' ' + (t.subtitle || '') + ' ' + terms + ' ' +
              (t.uz || '') + ' ' + (t.cam || '')).toLowerCase()
      };
    });
  }

  function openSearch() {
    var idx = searchIndex();
    if (!idx.length) { w.location.href = ROOT + 'grade.html?g=8'; return; }

    var box = document.createElement('div');
    box.className = 'findlayer';
    box.innerHTML =
      '<div class="findbox" role="dialog" aria-modal="true" aria-label="' + t('searchTitle') + '">' +
      '<div class="findtop">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
      'stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/>' +
      '<path d="M20 20l-4.3-4.3"/></svg>' +
      '<input type="search" id="findin" placeholder="' + t('searchPlaceholder', { n: idx.length }) + '" ' +
      'autocomplete="off" spellcheck="false">' +
      '<kbd>Esc</kbd></div><div class="findlist" id="findlist"></div></div>';
    document.body.appendChild(box);

    var input = box.querySelector('#findin'), list = box.querySelector('#findlist'), sel = 0, hits = [];

    function draw() {
      if (!hits.length) {
        list.innerHTML = '<p class="findnone">' + t('searchNone') + '</p>';
        return;
      }
      list.innerHTML = hits.map(function (h, i) {
        return '<a class="findrow' + (i === sel ? ' on' : '') + '" href="' +
          ROOT + 'lesson.html?t=' + h.id + '"><span class="ft">' + esc(h.title) +
          '</span><span class="fm">' + esc(h.meta) + '</span></a>';
      }).join('');
      var on = list.querySelector('.on');
      if (on) on.scrollIntoView({ block: 'nearest' });
    }
    function run() {
      var q = input.value.trim().toLowerCase();
      hits = idx.slice();
      if (q) {
        hits = [];
        for (var i = 0; i < idx.length; i++) {
          var t = idx[i], score = 0;
          if (t.lcTitle.indexOf(q) === 0) score = 4;          /* title starts with it */
          else if (t.lcTitle.indexOf(q) > -1) score = 3;      /* title contains it    */
          else if (t.lcSub.indexOf(q) > -1) score = 2;        /* subtitle             */
          else if (t.hay.indexOf(q) > -1) score = 1;          /* terminology or refs  */
          if (score) hits.push({ t: t, s: score, i: i });
        }
        hits.sort(function (a, b) { return b.s - a.s || a.i - b.i; });
        hits = hits.map(function (h) { return h.t; });
      }
      hits = hits.slice(0, 40);
      sel = 0; draw();
    }
    function shut() { if (box.parentNode) box.parentNode.removeChild(box); }

    input.addEventListener('input', run);
    box.addEventListener('click', function (e) { if (e.target === box) shut(); });
    document.addEventListener('keydown', function onKey(e) {
      if (!box.parentNode) { document.removeEventListener('keydown', onKey); return; }
      if (e.key === 'Escape') { shut(); }
      else if (e.key === 'ArrowDown') { e.preventDefault(); sel = Math.min(sel + 1, hits.length - 1); draw(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); sel = Math.max(sel - 1, 0); draw(); }
      else if (e.key === 'Enter' && hits[sel]) { w.location.href = ROOT + 'lesson.html?t=' + hits[sel].id; }
    });
    run();
    input.focus();
  }

  function searchBehaviour() {
    var b = document.getElementById('findbtn');
    if (b) b.addEventListener('click', openSearch);
    /* "/" opens search, the way most documentation sites do. */
    document.addEventListener('keydown', function (e) {
      if (e.key !== '/' || e.ctrlKey || e.metaKey) return;
      var t = e.target.tagName;
      if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return;
      if (document.querySelector('.findlayer')) return;
      e.preventDefault(); openSearch();
    });
  }

  /* ---------- preloader ----------
     Rules, in order of importance: never delay the reader, never flash, and
     never be the reason a page looks broken.

       - gone as soon as the page has loaded, but shown for at least MIN so it
         does not blink on a fast machine;
       - gone at MAX regardless, even if some asset hangs;
       - skipped completely on later pages in the same visit, and for anyone
         who has asked for reduced motion.

     The CSS carries its own failsafe too, so the overlay clears even if this
     script never runs. */

  var PRELOAD_MIN = 1150;   /* long enough for the mark to finish drawing */
  var PRELOAD_MAX = 2400;

  function preloader() {
    var el = document.getElementById('preload');
    if (!el) return;

    var seen = false;
    try { seen = sessionStorage.getItem('akm-seen') === '1'; } catch (e) { /* private mode */ }
    var still = w.matchMedia && w.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (seen || still) { el.parentNode.removeChild(el); return; }
    try { sessionStorage.setItem('akm-seen', '1'); } catch (e) { /* ignore */ }

    var start = Date.now(), gone = false;
    function dismiss() {
      if (gone) return;
      gone = true;
      el.classList.add('done');
      setTimeout(function () {
        if (el.parentNode) el.parentNode.removeChild(el);
      }, 460);
    }
    function whenReady() {
      setTimeout(dismiss, Math.max(0, PRELOAD_MIN - (Date.now() - start)));
    }
    if (document.readyState === 'complete') whenReady();
    else w.addEventListener('load', whenReady);
    setTimeout(dismiss, PRELOAD_MAX);
  }

  /* ---------- Language ----------
     The site's own three-way switch (English / O'zbekcha / Русский) lives in
     assets/i18n.js — it relabels the chrome instantly and, on a topic that
     has been translated, the lesson body too. No network request, nothing
     to fail offline. See langSwitcher() / langBehaviour() above. */

  /* The phrases the two marquees cycle. Written once, used by the strip above
     the footer and by the tilted band on the front page. */
  var SLOGAN = '<b>Forty minutes, five moves</b><i class="dot">◆</i>' +
    '<em>warm-up</em><i class="dot">·</i><em>explanation</em><i class="dot">·</i>' +
    '<em>interactive model</em><i class="dot">·</i><em>practice</em><i class="dot">·</i>' +
    '<em>homework</em><i class="dot">◆</i>' +
    '<b>Uzbekistan national programme &amp; Cambridge Lower Secondary</b>' +
    '<i class="dot">◆</i>';
  var TICKER = [
    ['Grades 5 – 11', 'national programme'],
    ['Cambridge Lower Secondary', 'stages 6 – 9'],
    ['21 graded problems', 'every topic'],
    ['Interactive models', 'built for the board'],
    ['Three languages', 'uz · ru · en'],
    ['Printable booklets', 'one per quarter']
  ];

  function ticker(cls) {
    var items = TICKER.map(function (t) {
      return '<b>' + t[0] + '</b><em>' + t[1] + '</em><i class="dot">◆</i>';
    }).join('');
    return '<div class="marquee ' + cls + '" aria-hidden="true">' +
      '<div class="marquee-track"><span>' + items + '</span></div></div>';
  }

  function footer() {
    return ticker('marquee--flat marquee--slow') +
      '<footer class="site-foot" id="sitefoot"><div class="inner">' +
      '<div>' + brandmark('Grades 5–11 · Uzbekistan &amp; Cambridge') + '</div>' +
      '<p class="fnote">' + t('footNote') + '</p>' +
      '</div></footer>';
  }

  function theme() {
    var KEY = 'akm-theme';
    var saved = null;
    try { saved = localStorage.getItem(KEY); } catch (e) { }
    if (saved === 'dark' || saved === 'light') document.documentElement.setAttribute('data-theme', saved);
    var b = document.getElementById('themebtn');
    if (!b) return;
    b.addEventListener('click', function () {
      var cur = document.documentElement.getAttribute('data-theme');
      if (!cur) {
        cur = w.matchMedia && w.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      }
      var next = cur === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem(KEY, next); } catch (e) { }
      /* the canvas scene sampled the old palette, so hand it the new one */
      if (w.HERO3D && w.HERO3D.retone) w.HERO3D.retone();
    });
  }

  /* The rotating solids beside the brandmark. Six shapes at different speeds,
     so the strip never falls into a single rhythm. */
  var STRIP = [
    { shape: 'cube',   colour: 'var(--brand)', speed: 1.00 },
    { shape: 'octa',   colour: 'var(--brass)', speed: -0.82 },
    { shape: 'sphere', colour: 'var(--brand)', speed: 0.64 },
    { shape: 'prism',  colour: 'var(--brass)', speed: -0.55 },
    { shape: 'cone',   colour: 'var(--brand)', speed: 0.73 },
    { shape: 'tetra',  colour: 'var(--brass)', speed: -0.91 }
  ];
  function mountSolids() {
    var host = document.getElementById('solidstrip');
    if (!host || !w.SOLIDS || host.childNodes.length) return;
    for (var i = 0; i < STRIP.length; i++) {
      var cell = document.createElement('span');
      cell.className = 'solidcell';
      host.appendChild(cell);
      w.SOLIDS.mount(cell, {
        shape: STRIP[i].shape, size: 26, colour: STRIP[i].colour,
        speed: STRIP[i].speed, phase: i * 1.05
      });
    }
  }

  function mount(active) {
    var h = document.getElementById('site-header');
    if (h) h.outerHTML = header(active);
    var f = document.getElementById('site-footer');
    if (f) f.outerHTML = footer();
    var head = document.getElementById('sitehead');
    if (head) head.setAttribute('data-active', active || '');
    theme();
    preloader();
    navBehaviour();
    searchBehaviour();
    langBehaviour();
    bindLangchangeOnce();
    mountSolids();
    /* Deferred by one frame on purpose. A page builds its card grids in the
       same inline script that called mount(), so the motion layer has to look
       at the finished document rather than this half of it. */
    if (w.AKM_MOTION) {
      if (w.requestAnimationFrame) w.requestAnimationFrame(w.AKM_MOTION.init);
      else w.AKM_MOTION.init();
    }
  }

  /* Every topic the page has loaded, whatever grade. Data files register
     themselves as G8_ALG, G10_GEO, G6_MAT and so on, so adding a grade is one
     more <script> tag and one more entry here. Grades 6 and 7 are taught as a
     single subject, hence the MAT stream. */
  var GRADE_KEYS = [6, 7, 8, 9, 10, 11];
  var STREAM_KEYS = ['MAT', 'ALG', 'GEO'];
  function allTopics() {
    var out = [], i, j;
    for (i = 0; i < GRADE_KEYS.length; i++) {
      for (j = 0; j < STREAM_KEYS.length; j++) {
        out = out.concat(w['G' + GRADE_KEYS[i] + '_' + STREAM_KEYS[j]] || []);
      }
    }
    return out;
  }

  function qs(name) {
    var m = new RegExp('[?&]' + name + '=([^&#]*)').exec(w.location.search);
    return m ? decodeURIComponent(m[1].replace(/\+/g, ' ')) : null;
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  w.AKM_allTopics = allTopics;
  w.AKM = { LOGO: LOGO, ROOT: ROOT, mount: mount, qs: qs, esc: esc, brandmark: brandmark };
})(window);
